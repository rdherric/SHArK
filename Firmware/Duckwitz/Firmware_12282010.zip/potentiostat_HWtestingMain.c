//-----------------------------------------------------------------------------
// potentiostat_2v0.c
//-----------------------------------------------------------------------------
// Copyright (C) RDHC2, LLC
// http://www.rdh2.com/
//
// Program Description:
//
// This program is to verify the potentiostat hardware.
// Specifically, it verifies the functionality of the DAC and ADC for
// setting the output voltage and measuring the resulting current.
//
//
// Target:         C8051F32x
// Tool chain:     SDCC 2.7.0 (version may not be correct)
// Command Line:   None
//
// Release 1.0 / Not Released
//    -Initial Revision

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include "compiler_defs.h"
#include "C8051F320_defs.h"            // SFR declarations

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define SYSCLK       24000000			// SYSCLK frequency in Hz
#define round(x) ((x)>=0?(int)((x)+0.5):(int)((x)-0.5))

// Define names for bits in special function registers.
// If these change, update PORT_Init() also.
SBIT(M2DIR, SFR_P0, 3);					// Motor 2 direction
SBIT(M2STEP, SFR_P0, 4);				// Motor 2 step (on rising edge)
SBIT(NDRIVEREN, SFR_P0,5);				// Not stepper motor driver enable
SBIT(M1DIR, SFR_P1, 6);					// Motor 1 direction
SBIT(M1STEP, SFR_P0, 7);				// Motor 1 step (on rising edge)
SBIT(INTTL, SFR_P1, 0);					// Input TTL signal
SBIT(OUTTTL, SFR_P1, 1);				// Output TTL signal (120 Hz, 38 pulses)
SBIT(LASER, SFR_P1, 2);					// Laser power on
SBIT(NDACCS, SFR_P1, 4);				// Not CS for DAC SPI
SBIT(CAL, SFR_P1, 7);					// Calibration on
SBIT(POS, SFR_P2, 0);					// Positive current
SBIT(NADCCS, SFR_P2, 1);				// Not CS for ADC SPI
SBIT(OUTPUTEN, SFR_P2, 3);				// Potentiostat output current enable
SBIT(NRAMCS, SFR_P2, 6);				// Not CS for RAM SPI
SBIT(NRAMHOLD, SFR_P2, 7);				// Not hold for RAM
SBIT(ERRORPIN, SFR_P2, 2);				// Error pin high when there's an error

// Temporary definitions for testing on development board
SBIT(NotDriverEN, SFR_P0, 5);			// NotDriverEN='0' means driver ICs enabled and
										// current from the +12 V supply will be flowing.
SBIT(Motor1Dir, SFR_P0, 6);				// Motor 1 Direction
SBIT(Motor1Step, SFR_P0, 7);			// Motor 1 Step when this DIO is pulsed
SBIT(Motor2Dir, SFR_P0, 3);				// Motor 2 Direction
SBIT(Motor2Step, SFR_P0, 4);			// Motor 2 Step when this DIO is pulsed
//SBIT(SW2, SFR_P2, 0);					// SW2='0' means switch pressed

// Special Function Register masks
#define MULRDY	0x20		// Clock multiplier read, SFR is CLKMUL

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void SPI_Init (void);
void DAC_Init (void);
void ADC_Init(void);

INTERRUPT_PROTO(SPI_ISR, INTERRUPT_SPI0);

// Global variables
int Writing_to_DAC = 0;					// Boolean: still need to write >=1 byte via SPI
int Writing_to_ADC = 0;					// Boolean: still need to write >=1 byte via SPI
int SPI_DAC_Bytes = 0;					// No. of bytes to/from DAC: 0-3
int SPI_ADC_Bytes = 0;					// No. of bytes to/from ADC: 0-2
int latest_ADC_HighByte;				// High ADC measurement byte
int latest_ADC_LowByte;					// Low ADC measurement byte


//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void)
{
	// Declare a delay variable
	int delay = 0;

	PCA0MD &= ~0x40;					// Disable watchdog timer

	ERRORPIN = 0;
	latest_ADC_LowByte = 0;
	latest_ADC_HighByte = 0;

	SYSCLK_Init ();					// Initialize system clock to 24 MHz
									// and USB clock to 48 MHz

	PORT_Init ();					// Initialize crossbar and GPIO

	EA = 1;							// Enable global interrupts

	SPI_Init();						// Set up SPI peripheral
	DAC_Init();						// Call just after SPI_Init for proper function
	ADC_Init();

	OUTPUTEN = 1;					// emable output, close relay K601
	CAL = 0;

	//
	// Set DAC output voltage (testing)
	//
	// To calculate a negative value for a positive Potentiostat output and
	// positive current
	//
	// POSTITIVE voltage at the reference node and a positive current into
	// the working node, use a _negative voltage at the DAC output:
	// Value = 0x10000 - |Voltage|*3277 - 0x0024
	// Voltage = (Value - 0xFFDC) / 3277 
	//   Example: to get +0.1 V at the reference node, output -0.1 V at the DAC
	//   0x8000 - 0.1*3277 = 0xFEB8 = 65244	
	//
	//  - 0xA
	//
	// NEGATIVE voltage at the reference node and a negative current into
	// the working node, use a _positive voltage at the DAC output:
	// Value = Voltage*3277 - 0x0024
	//   Example: to get -0.1 V at the reference node, output +0.1 V at the DAC
	//   0.1*3277 = 0x0148 = 328
	SPI0CFG = 0x50;					// Set the clock polarity and phase for the DAC
	POS = 1;
	NDACCS = 0;						// Select the DAC for SPI communication
	Writing_to_DAC = 1;
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
//	SPI0DAT = upperByte;			// Upper part of byte
//	was 0x22
	SPI0DAT = 0xFD;					// Upper part of byte
	while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
//	SPI0DAT = lowerByte;			// Lower part of byte
//	was 0xA6
	SPI0DAT = 0x71;					// Lower part of byte
	while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
	SPI_DAC_Bytes = 0;				// Reset byte TX counter
	NDACCS = 1;						// Deselect the DAC for SPI communication
	Writing_to_DAC = 0;

	// 2 bytes to send
	//	15 = EN1 = 0 to read data
	//	14 = EN2 = 0 to read data
	//	13-00 = Don't care
	// ADC: send 0110 0000 0000 0000
	SPI0CFG = 0x40;					// Set the clock polarity and phase for the ADC
	NADCCS = 0;						// Select the ADC for SPI communication
	while (delay < 1000)
		{ delay++; }

	Writing_to_ADC = 1;
	SPI0DAT = 0xA0;					// 0xA0 = 1010 0000
	while(SPI_ADC_Bytes != 1) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_ADC_Bytes != 2) {}	// wait for SPI to finish sending byte
	NADCCS = 1;						// Deselect the ADC for SPI communication
	Writing_to_ADC = 0;
}


//-----------------------------------------------------------------------------
// SPI_Init
//-----------------------------------------------------------------------------
//
// Return Value: none
// Parameters:   none
//
// Initialize SPI.  The initialization sets parameters to talk to the DAC
// (AD5754), so some things are changed later to talk to the ADC and RAM.
//
//-----------------------------------------------------------------------------
void SPI_Init (void)
{
	// Set all SPI chip selects to Not Selected or 1
	NDACCS = 1;
	NADCCS = 1;
	NRAMCS = 1;

	// SPI configuration register: SPI0CFG
	//  7 SPIBSY	R
	//  6 MSTEN		R/W
	//  5 CKPHA		R/W
	//  4 CKPOL		R/W
	//  3 SLVSEL	R
	//  2 NSSIN		R
	//  1 SRMT		R
	//  0 RXBMT		R
	SPI0CFG = 0x50;				// 0x60 = 0101 0000

	// SPI control register: SPI0CN
	//  7 SPIF		R/W
	//  6 WCOL		R/W
	//  5 MODF		R/W
	//  4 RXOVRN	R/W
	//  3 NSSMD1	R/W
	//  2 NSSMD0	R/W
	//  1 TXBMT		R
	//  0 SPIEN		R/W
	SPI0CN = 0x01;				// 0x01 = 0000 0001

	// SPI clock rate register: SPI0CKR
	//  7 SCR7		R/W
	//  ...
	//  0 SCR0		R/W
	// The SPI clock is a divided version of SYSCLK = 24 MHz:
	//                SYSCLK
	//  f_SCK = ------------------
	//           2 x (SPI0CKR + 1)
	// So f_SCK = 12 MHz (for the DAC and RAM) is SPI0CKR = 0x00
	// and f_SCK = 2 MHz (for the ADC) is SPI0CKR = 0x05
	SPI0CKR = 0x05;				// 0x00 = 0000 0101

	// Enable SPI interrupts, SFR IE, bit 6
	ESPI0 = 1;
}


//-----------------------------------------------------------------------------
// SPI_ISR
//-----------------------------------------------------------------------------
//
// This routine...
//
//-----------------------------------------------------------------------------
INTERRUPT(SPI_ISR, INTERRUPT_SPI0)
{
	int RXbyte;		// received byte
	// Interrupt flag, 4 possibilities (p. 199)
	//	0x80 = TX complete, receive byte ready to readk
	//	0x40 = write collision, when SPI0DAT is written prior to last TX
	//	0x20 = mode fault, NSS is pulled low during multi-master mode
	//	0x10 = RX overrun, received a byte before last one was read (slave mode)

	// Determine what caused the interrupt
	if ((SPI0CN & 0x80) == 0x80)		// TX complete, byte ready to read
	{
		SPIF = 0;			// clear interrupt flag
		RXbyte = SPI0DAT;	// This could be a byte from the DAC, ADC, or RAM.
		if (Writing_to_ADC > 0)			// ADC
		{
			if (SPI_ADC_Bytes == 0)
			{
				latest_ADC_HighByte = RXbyte;
			}
			else if (SPI_ADC_Bytes == 1)
			{
				latest_ADC_LowByte = RXbyte;
			}
			SPI_ADC_Bytes++;			// Do not zero in this ISR
		}
		else if (Writing_to_DAC > 0)	// DAC
		{
			SPI_DAC_Bytes++;			// Do not zero in this ISR
		}
		else							// ERROR
		{
			ERRORPIN = 1;
		}
	}
	if ((SPI0CN & 0x40) == 0x40)	// write collision
	{
		WCOL = 0;		// clear interrupt flag
	}
	if ((SPI0CN & 0x20) == 0x20)	// mode fault
	{
		MODF = 0;		// clear interrupt flag
	}
	if ((SPI0CN & 0x10) == 0x10)	// RX overrun
	{
		RXOVRN = 0;		// clear interrupt flag
	}
}


//-----------------------------------------------------------------------------
// DAC_Init
//-----------------------------------------------------------------------------
//
// Return Value: none
// Parameters:   none
//
// Initialize DAC.  Assumes SPI_Init was just called and CKPOL and CKPHA are set
// correctly.
//
//-----------------------------------------------------------------------------
void DAC_Init (void)
{
	Writing_to_DAC = 1;
	SPI_DAC_Bytes = 0;

	////
	//// SELECT OUTPUT RANGE
	////
	// 3 bytes to send
	//	23 = R/W = 0 for write
	//	22 = Not used = 0 must be zero
	//	21-19 = Reg2-Reg0 = 001
	//	18-16 = A2-A0 = DAC address, A = 000, B = 001, C = 010, D = 011
	//	15-03 = Don't care
	//	02-00 = 100 for +/- 10 V
	// DAC A: send 0000 1000 0000 0000 0000 0100
	NDACCS = 0;						// Select the DAC for SPI communication
	SPI0DAT = 0x08;					// 0x08 = 0000 1000
	while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x04;					// 0x04 = 0000 0100
	while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
	SPI_DAC_Bytes = 0;				// Reset byte TX counter
	NDACCS = 1;						// Deselect the DAC for SPI communication

	////
	//// CONTROL REGISTER
	////
	// 3 bytes to send
	//	23 = R/W = 0 for write
	//	22 = Not used = 0 must be zero
	//	21-19 = Reg2-Reg0 = 011
	//	18-16 = A2-A0 = command, = 001 for various enables/disables
	//	15-04 = Don't care
	//	03 = thermal shutdown enable = 1 for enable
	//	02 = current clamp enable = 1 for enable
	//	01 = clear select = 1 for full range
	//	00 = serial data out disable = 0 for enable
	// DAC A: send 0001 1001 0000 0000 0000 1110
	NDACCS = 0;						// Select the DAC for SPI communication
	SPI0DAT = 0x19;					// 0x19 = 0001 1001
	while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x0E;					// 0x0E = 0000 1110
	while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
	SPI_DAC_Bytes = 0;				// Reset byte TX counter
	NDACCS = 1;						// Deselect the DAC for SPI communication

	////
	//// POWER CONTROL REGISTER
	////
	// 3 bytes to send
	//	23 = R/W = 0 for write
	//	22 = Not used = 0 must be zero
	//	21-19 = Reg2-Reg0 = 010
	//	18-16 = A2-A0 = unused?, = 000 (Table 26, p. 26)
	//	15-11 = Don't care
	//	10-07 = Overcurrent alert (read only) for DACs A-D, respectively
	//	06 = reserved bit, 0
	//	05 = thermal shutdown alert (read only)
	//	04 = reserved bit, 0
	//	03-00 = power up for DACs D-A, respectively. 1 for normal operating
	//			mode. 0 for power-down mode.  MCU sets to 0 if clamp disabled
	//			and overcurrent detected.
	// DAC A: send 0001 0000 0000 0000 0000 1111
	NDACCS = 0;						// Select the DAC for SPI communication
	SPI0DAT = 0x10;					// 0x10 = 0001 0000
	while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x0F;					// 0x0F = 0000 0001
	while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
	SPI_DAC_Bytes = 0;				// Reset byte TX counter
	NDACCS = 1;						// Deselect the DAC for SPI communication

	Writing_to_DAC = 0;
}


//-----------------------------------------------------------------------------
// ADC_Init
//-----------------------------------------------------------------------------
//
// Return Value: none
// Parameters:   none
//
// Initialize ADC.  Must reset the SPI timing, clock polarization, and clock
// phase.
//
//-----------------------------------------------------------------------------
void ADC_Init (void)
{
	int delay = 0;
	Writing_to_ADC = 1;
	SPI_ADC_Bytes = 0;

	////
	//// Write configuration to ADC
	////

	// 2 bytes to send
	//	15 = EN1 = 1 to write data
	//	14 = EN2 = 0 to write data
	//	13 = SPD = 1 for 1 kHz conversion rate (0 would be for 250 Hz)
	//	12 = SLP = 0 for NAP, SLEEP disabled (12 ms to wake from SLEEP)
	//	11-00 = Don't care
	// ADC: send 1010 0000 0000 0000
	SPI0CFG = 0x40;
	NADCCS = 0;						// Select the DAC for SPI communication
	while (delay < 1000)			// Delay for at least 12 ms @ SYSCLK = 24 MHz 
		{ delay++; }
	SPI0DAT = 0xA0;					// 0xA0 = 1010 0000
	while(SPI_ADC_Bytes != 1) {}	// wait for SPI to finish sending byte
	SPI0DAT = 0x00;					// 0x00 = 0000 0000
	while(SPI_ADC_Bytes != 2) {}	// wait for SPI to finish sending byte
	NADCCS = 1;						// Deselect the DAC for SPI communication
	SPI_ADC_Bytes = 0;				// Reset the ADC Counter

	Writing_to_ADC = 0;
}


//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// Return Value: none
// Parameters:   none
//
// This routine initializes the system clock to 24 MHz and the USB clock to
// 48 MHz (USB 2.0 requirement).  The 4x clock multiplier is employed, so
// the USB clock is 12 MHz * 4 = 48 MHz.  The system clock is set to the 4x
// oscillator divided by 2, 12 MHz * 4 / 2 = 24 MHz.  Also enables missing
// clock detector reset (required for this setup).
//
// This setup was verified by blinking an LED using the 16-bit TIMER2 and a
// loop that ran 10 times.  TIMER2 was run from the system clock / 12.
// Blink Period =  10 * 2^16 / (24 MHz / (2*12)) = 0.655 s
// (Factor of 2 for two cycles per blink period.)
//
//-----------------------------------------------------------------------------
void SYSCLK_Init (void)
{
	// Local variables
	int delay = 0;

	// Configure internal oscillator
	OSCICN = 0x83;

	// Set up clock multiplier to allow for a 48 MHz USB clock.
	CLKMUL = 0x00;		// Reset clock multiplier
	CLKMUL |= 0x80;		// Enable multiplier
	// Delay for >5us (48MHz * 20ps = 240 clock cycles)
	while (delay < 300) { delay += 1; }
	CLKMUL |= 0xC0;		// Initialize multiplier
	// Poll for multiplier ready
	while ((CLKMUL & MULRDY) != MULRDY) { NOP(); }
	CLKSEL = 0x02;		// USB clock = 4*(Int Osc)
						// Sys clock = 4*(Int Osc)/2

	RSTSRC = 0x04;		// Enable missing clock detector, required for USB
}


//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value: none
// Parameters:   none
//
// Configure the Crossbar and GPIO ports.
//
// P0.0 - SCK (SPI)
// P0.1 - MISO (SPI)
// P0.2 - MOSI (SPI)
// P0.3 - Motor 2 Direction (Stepper Motor Driver)
// P0.4 - Motor 2 Step (Stepper Motor Driver)
// P0.5 - Not Driver Enable (Stepper Motor Driver)
// P0.6 - Motor 1 Direction (Stepper Motor Driver)
// P0.7 - Motor 1 Step (Stepper Motor Driver)
// P1.0 - In TTL
// P1.1 - Out TTL
// P1.2 - Laser Power On/Off
// P1.3 - N/C
// P1.4 - Not DAC CS (SPI)
// P1.5 - N/C
// P1.6 - N/C
// P1.7 - Calibration (logical)
// P2.0 - Positive Current (logical)
// P2.1 - Not ADC CS (SPI)
// P2.2 - N/C (LED, push-pull, temporary for testing purposes)
// P2.3 - Output Enable
// P2.4 - N/C
// P2.5 - N/C
// P2.6 - Not RAM CS (SPI)
// P2.7 - Not RAM Hold
// P3.0 - N/C
//
//-----------------------------------------------------------------------------
void PORT_Init (void)
{
	// Set all port pins as NOT analog inputs.
	P0MDIN = 0xFF;
	P1MDIN = 0xFF;
	P2MDIN = 0xFF;
	P3MDIN = 0xFF;

	// Select push/pull for all port pins
	P0MDOUT = 0xFD;				// 1111 1101
	P1MDOUT = 0xFF;
	P2MDOUT = 0xFF;
	P3MDOUT = 0xFF;

	// Set the P0.1 as Digital In
	P0 = 0x02;					// 0000 0010

	// Select pins to be skipped by port crossbar
	P0SKIP = 0x00;
	P1SKIP = 0x00;
	P2SKIP = 0x00;
//	P0SKIP = 0xF8;				// Don't skip the 3 wires for SPI
//	P1SKIP = 0xFF;
//	P2SKIP = 0xFF;

	// Assign port pins to peripherals using the port crossbar (p. 131)
	XBR0 = 0x02;				// Only SPI selected, automatically assigned:
								// SCK  --> P0.0
								// MISO --> P0.1
								// MOSI --> P0.2
	XBR1 = 0x40;				// Enable crossbar and weak pull-ups


	// Initialize the potentiostat state
	// 1. the SPI Not Chip Select ports to high (P1.4, P2.1, P2.6)
	// 2. the stepper motor Not Enable to high (P0.5)
	// 3. the stepper motors "step" ports to low (P0.4, P0.7)
	// 4. the laser power low (P1.2)
	// 5. the Calibration signal to low (P1.7)
	// 6. the current direction signal Positive to high (P2.0)
	// 7. the Output Enable to low (P2.3)
	// 8. the Not RAM Hold to high (P2.7)
//	P0 = 0x20;					// 0x20 = 0010 0000b
//	P1 = 0x10;					// 0x10 = 0001 0000b
//	P2 = 0xC3;					// 0xC3 = 1100 0011b
	NADCCS = 1;
	NDACCS = 1;
	NRAMCS = 1;
	NRAMHOLD = 1;
	NotDriverEN = 1;			// Enable/disable (0/1) stepper motor driver
								// A 0 causes current from +12 V to flow!
	Motor1Dir = 0;
	Motor2Dir = 0;
	Motor1Step = 0;
	Motor2Step = 0;
	LASER = 0;					// Disable laswer power
	OUTPUTEN = 0;				// Disable the output until we're ready
	POS = 1;					// Positive voltage and current
	CAL = 0;					// Not in calibration state
}
