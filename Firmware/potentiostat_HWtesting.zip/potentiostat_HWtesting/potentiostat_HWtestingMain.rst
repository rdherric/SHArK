                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 2.9.7 #5799 (Apr 10 2010) (MINGW32)
                              4 ; This file was generated Fri Oct 22 07:14:33 2010
                              5 ;--------------------------------------------------------
                              6 	.module potentiostat_HWtestingMain
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _ADC_Init
                             13 	.globl _main
                             14 	.globl _Motor2Step
                             15 	.globl _Motor2Dir
                             16 	.globl _Motor1Step
                             17 	.globl _Motor1Dir
                             18 	.globl _NotDriverEN
                             19 	.globl _ERRORPIN
                             20 	.globl _NRAMHOLD
                             21 	.globl _NRAMCS
                             22 	.globl _OUTPUTEN
                             23 	.globl _NADCCS
                             24 	.globl _POS
                             25 	.globl _CAL
                             26 	.globl _NDACCS
                             27 	.globl _LASER
                             28 	.globl _OUTTTL
                             29 	.globl _INTTL
                             30 	.globl _M1STEP
                             31 	.globl _M1DIR
                             32 	.globl _NDRIVEREN
                             33 	.globl _M2STEP
                             34 	.globl _M2DIR
                             35 	.globl _SPIEN
                             36 	.globl _TXBMT
                             37 	.globl _NSSMD0
                             38 	.globl _NSSMD1
                             39 	.globl _RXOVRN
                             40 	.globl _MODF
                             41 	.globl _WCOL
                             42 	.globl _SPIF
                             43 	.globl _AD0CM0
                             44 	.globl _AD0CM1
                             45 	.globl _AD0CM2
                             46 	.globl _AD0WINT
                             47 	.globl _AD0BUSY
                             48 	.globl _AD0INT
                             49 	.globl _AD0TM
                             50 	.globl _AD0EN
                             51 	.globl _CCF0
                             52 	.globl _CCF1
                             53 	.globl _CCF2
                             54 	.globl _CCF3
                             55 	.globl _CCF4
                             56 	.globl _CR
                             57 	.globl _CF
                             58 	.globl _P
                             59 	.globl _F1
                             60 	.globl _OV
                             61 	.globl _RS0
                             62 	.globl _RS1
                             63 	.globl _F0
                             64 	.globl _AC
                             65 	.globl _CY
                             66 	.globl _T2XCLK
                             67 	.globl _TR2
                             68 	.globl _T2SPLIT
                             69 	.globl _T2SOF
                             70 	.globl _TF2LEN
                             71 	.globl _TF2L
                             72 	.globl _TF2H
                             73 	.globl _SI
                             74 	.globl _ACK
                             75 	.globl _ARBLOST
                             76 	.globl _ACKRQ
                             77 	.globl _STO
                             78 	.globl _STA
                             79 	.globl _TXMODE
                             80 	.globl _MASTER
                             81 	.globl _PX0
                             82 	.globl _PT0
                             83 	.globl _PX1
                             84 	.globl _PT1
                             85 	.globl _PS0
                             86 	.globl _PT2
                             87 	.globl _PSPI0
                             88 	.globl _EX0
                             89 	.globl _ET0
                             90 	.globl _EX1
                             91 	.globl _ET1
                             92 	.globl _ES0
                             93 	.globl _ET2
                             94 	.globl _ESPI0
                             95 	.globl _EA
                             96 	.globl _RI0
                             97 	.globl _TI0
                             98 	.globl _RB80
                             99 	.globl _TB80
                            100 	.globl _REN0
                            101 	.globl _MCE0
                            102 	.globl _S0MODE
                            103 	.globl _IT0
                            104 	.globl _IE0
                            105 	.globl _IT1
                            106 	.globl _IE1
                            107 	.globl _TR0
                            108 	.globl _TF0
                            109 	.globl _TR1
                            110 	.globl _TF1
                            111 	.globl _PCA0CP4
                            112 	.globl _PCA0CP0
                            113 	.globl _PCA0
                            114 	.globl _PCA0CP3
                            115 	.globl _PCA0CP2
                            116 	.globl _PCA0CP1
                            117 	.globl _TMR2
                            118 	.globl _TMR2RL
                            119 	.globl _ADC0LT
                            120 	.globl _ADC0GT
                            121 	.globl _ADC0
                            122 	.globl _TMR3
                            123 	.globl _TMR3RL
                            124 	.globl _DP
                            125 	.globl _VDM0CN
                            126 	.globl _PCA0CPH4
                            127 	.globl _PCA0CPL4
                            128 	.globl _PCA0CPH0
                            129 	.globl _PCA0CPL0
                            130 	.globl _PCA0H
                            131 	.globl _PCA0L
                            132 	.globl _SPI0CN
                            133 	.globl _EIP2
                            134 	.globl _EIP1
                            135 	.globl _P3MDIN
                            136 	.globl _P2MDIN
                            137 	.globl _P1MDIN
                            138 	.globl _P0MDIN
                            139 	.globl _B
                            140 	.globl _RSTSRC
                            141 	.globl _PCA0CPH3
                            142 	.globl _PCA0CPL3
                            143 	.globl _PCA0CPH2
                            144 	.globl _PCA0CPL2
                            145 	.globl _PCA0CPH1
                            146 	.globl _PCA0CPL1
                            147 	.globl _ADC0CN
                            148 	.globl _EIE2
                            149 	.globl _EIE1
                            150 	.globl _IT01CF
                            151 	.globl _XBR1
                            152 	.globl _XBR0
                            153 	.globl _ACC
                            154 	.globl _PCA0CPM4
                            155 	.globl _PCA0CPM3
                            156 	.globl _PCA0CPM2
                            157 	.globl _PCA0CPM1
                            158 	.globl _PCA0CPM0
                            159 	.globl _PCA0MD
                            160 	.globl _PCA0CN
                            161 	.globl _USB0XCN
                            162 	.globl _P2SKIP
                            163 	.globl _P1SKIP
                            164 	.globl _P0SKIP
                            165 	.globl _REF0CN
                            166 	.globl _PSW
                            167 	.globl _TMR2H
                            168 	.globl _TMR2L
                            169 	.globl _TMR2RLH
                            170 	.globl _TMR2RLL
                            171 	.globl _REG0CN
                            172 	.globl _TMR2CN
                            173 	.globl _ADC0LTH
                            174 	.globl _ADC0LTL
                            175 	.globl _ADC0GTH
                            176 	.globl _ADC0GTL
                            177 	.globl _SMB0DAT
                            178 	.globl _SMB0CF
                            179 	.globl _SMB0CN
                            180 	.globl _ADC0H
                            181 	.globl _ADC0L
                            182 	.globl _ADC0CF
                            183 	.globl _AMX0P
                            184 	.globl _AMX0N
                            185 	.globl _CLKMUL
                            186 	.globl _IP
                            187 	.globl _FLKEY
                            188 	.globl _FLSCL
                            189 	.globl _OSCICL
                            190 	.globl _OSCICN
                            191 	.globl _OSCXCN
                            192 	.globl _P3
                            193 	.globl _EMI0CN
                            194 	.globl _CLKSEL
                            195 	.globl _IE
                            196 	.globl _P3MDOUT
                            197 	.globl _P2MDOUT
                            198 	.globl _P1MDOUT
                            199 	.globl _P0MDOUT
                            200 	.globl _SPI0DAT
                            201 	.globl _SPIDAT
                            202 	.globl _SPI0CKR
                            203 	.globl _SPICKR
                            204 	.globl _SPI0CFG
                            205 	.globl _SPICFG
                            206 	.globl _P2
                            207 	.globl _CPT0MX
                            208 	.globl _CPT1MX
                            209 	.globl _CPT0MD
                            210 	.globl _CPT1MD
                            211 	.globl _CPT0CN
                            212 	.globl _CPT1CN
                            213 	.globl _SBUF0
                            214 	.globl _SCON0
                            215 	.globl _USB0DAT
                            216 	.globl _USB0ADR
                            217 	.globl _TMR3H
                            218 	.globl _TMR3L
                            219 	.globl _TMR3RLH
                            220 	.globl _TMR3RLL
                            221 	.globl _TMR3CN
                            222 	.globl _P1
                            223 	.globl _PSCTL
                            224 	.globl _CKCON
                            225 	.globl _TH1
                            226 	.globl _TH0
                            227 	.globl _TL1
                            228 	.globl _TL0
                            229 	.globl _TMOD
                            230 	.globl _TCON
                            231 	.globl _PCON
                            232 	.globl _DPH
                            233 	.globl _DPL
                            234 	.globl _SP
                            235 	.globl _P0
                            236 	.globl _loop_cnt
                            237 	.globl _RAM_from_ptr_high
                            238 	.globl _RAM_from_ptr_low
                            239 	.globl _RAM_to_ptr_high
                            240 	.globl _RAM_to_ptr_low
                            241 	.globl _Write_to_RAM
                            242 	.globl _latest_ADC_LowByte
                            243 	.globl _latest_ADC_HighByte
                            244 	.globl _ADC_timer_MSB
                            245 	.globl _ADC_settled
                            246 	.globl _ADC_timer
                            247 	.globl _SPI_RAM_Bytes
                            248 	.globl _SPI_ADC_Bytes
                            249 	.globl _SPI_DAC_Bytes
                            250 	.globl _Writing_to_RAM
                            251 	.globl _Writing_to_ADC
                            252 	.globl _Writing_to_DAC
                            253 	.globl _SYSCLK_Init
                            254 	.globl _PORT_Init
                            255 	.globl _Timer1_Init
                            256 	.globl _Timer2_Init
                            257 	.globl _SPI_Init
                            258 	.globl _DAC_Init
                            259 	.globl _RAM_Write
                            260 	.globl _SPI_ISR
                            261 	.globl _Timer1_ISR
                            262 	.globl _Timer2_ISR
                            263 ;--------------------------------------------------------
                            264 ; special function registers
                            265 ;--------------------------------------------------------
                            266 	.area RSEG    (ABS,DATA)
   0000                     267 	.org 0x0000
                    0080    268 G$P0$0$0 == 0x0080
                    0080    269 _P0	=	0x0080
                    0081    270 G$SP$0$0 == 0x0081
                    0081    271 _SP	=	0x0081
                    0082    272 G$DPL$0$0 == 0x0082
                    0082    273 _DPL	=	0x0082
                    0083    274 G$DPH$0$0 == 0x0083
                    0083    275 _DPH	=	0x0083
                    0087    276 G$PCON$0$0 == 0x0087
                    0087    277 _PCON	=	0x0087
                    0088    278 G$TCON$0$0 == 0x0088
                    0088    279 _TCON	=	0x0088
                    0089    280 G$TMOD$0$0 == 0x0089
                    0089    281 _TMOD	=	0x0089
                    008A    282 G$TL0$0$0 == 0x008a
                    008A    283 _TL0	=	0x008a
                    008B    284 G$TL1$0$0 == 0x008b
                    008B    285 _TL1	=	0x008b
                    008C    286 G$TH0$0$0 == 0x008c
                    008C    287 _TH0	=	0x008c
                    008D    288 G$TH1$0$0 == 0x008d
                    008D    289 _TH1	=	0x008d
                    008E    290 G$CKCON$0$0 == 0x008e
                    008E    291 _CKCON	=	0x008e
                    008F    292 G$PSCTL$0$0 == 0x008f
                    008F    293 _PSCTL	=	0x008f
                    0090    294 G$P1$0$0 == 0x0090
                    0090    295 _P1	=	0x0090
                    0091    296 G$TMR3CN$0$0 == 0x0091
                    0091    297 _TMR3CN	=	0x0091
                    0092    298 G$TMR3RLL$0$0 == 0x0092
                    0092    299 _TMR3RLL	=	0x0092
                    0093    300 G$TMR3RLH$0$0 == 0x0093
                    0093    301 _TMR3RLH	=	0x0093
                    0094    302 G$TMR3L$0$0 == 0x0094
                    0094    303 _TMR3L	=	0x0094
                    0095    304 G$TMR3H$0$0 == 0x0095
                    0095    305 _TMR3H	=	0x0095
                    0096    306 G$USB0ADR$0$0 == 0x0096
                    0096    307 _USB0ADR	=	0x0096
                    0097    308 G$USB0DAT$0$0 == 0x0097
                    0097    309 _USB0DAT	=	0x0097
                    0098    310 G$SCON0$0$0 == 0x0098
                    0098    311 _SCON0	=	0x0098
                    0099    312 G$SBUF0$0$0 == 0x0099
                    0099    313 _SBUF0	=	0x0099
                    009A    314 G$CPT1CN$0$0 == 0x009a
                    009A    315 _CPT1CN	=	0x009a
                    009B    316 G$CPT0CN$0$0 == 0x009b
                    009B    317 _CPT0CN	=	0x009b
                    009C    318 G$CPT1MD$0$0 == 0x009c
                    009C    319 _CPT1MD	=	0x009c
                    009D    320 G$CPT0MD$0$0 == 0x009d
                    009D    321 _CPT0MD	=	0x009d
                    009E    322 G$CPT1MX$0$0 == 0x009e
                    009E    323 _CPT1MX	=	0x009e
                    009F    324 G$CPT0MX$0$0 == 0x009f
                    009F    325 _CPT0MX	=	0x009f
                    00A0    326 G$P2$0$0 == 0x00a0
                    00A0    327 _P2	=	0x00a0
                    00A1    328 G$SPICFG$0$0 == 0x00a1
                    00A1    329 _SPICFG	=	0x00a1
                    00A1    330 G$SPI0CFG$0$0 == 0x00a1
                    00A1    331 _SPI0CFG	=	0x00a1
                    00A2    332 G$SPICKR$0$0 == 0x00a2
                    00A2    333 _SPICKR	=	0x00a2
                    00A2    334 G$SPI0CKR$0$0 == 0x00a2
                    00A2    335 _SPI0CKR	=	0x00a2
                    00A3    336 G$SPIDAT$0$0 == 0x00a3
                    00A3    337 _SPIDAT	=	0x00a3
                    00A3    338 G$SPI0DAT$0$0 == 0x00a3
                    00A3    339 _SPI0DAT	=	0x00a3
                    00A4    340 G$P0MDOUT$0$0 == 0x00a4
                    00A4    341 _P0MDOUT	=	0x00a4
                    00A5    342 G$P1MDOUT$0$0 == 0x00a5
                    00A5    343 _P1MDOUT	=	0x00a5
                    00A6    344 G$P2MDOUT$0$0 == 0x00a6
                    00A6    345 _P2MDOUT	=	0x00a6
                    00A7    346 G$P3MDOUT$0$0 == 0x00a7
                    00A7    347 _P3MDOUT	=	0x00a7
                    00A8    348 G$IE$0$0 == 0x00a8
                    00A8    349 _IE	=	0x00a8
                    00A9    350 G$CLKSEL$0$0 == 0x00a9
                    00A9    351 _CLKSEL	=	0x00a9
                    00AA    352 G$EMI0CN$0$0 == 0x00aa
                    00AA    353 _EMI0CN	=	0x00aa
                    00B0    354 G$P3$0$0 == 0x00b0
                    00B0    355 _P3	=	0x00b0
                    00B1    356 G$OSCXCN$0$0 == 0x00b1
                    00B1    357 _OSCXCN	=	0x00b1
                    00B2    358 G$OSCICN$0$0 == 0x00b2
                    00B2    359 _OSCICN	=	0x00b2
                    00B3    360 G$OSCICL$0$0 == 0x00b3
                    00B3    361 _OSCICL	=	0x00b3
                    00B6    362 G$FLSCL$0$0 == 0x00b6
                    00B6    363 _FLSCL	=	0x00b6
                    00B7    364 G$FLKEY$0$0 == 0x00b7
                    00B7    365 _FLKEY	=	0x00b7
                    00B8    366 G$IP$0$0 == 0x00b8
                    00B8    367 _IP	=	0x00b8
                    00B9    368 G$CLKMUL$0$0 == 0x00b9
                    00B9    369 _CLKMUL	=	0x00b9
                    00BA    370 G$AMX0N$0$0 == 0x00ba
                    00BA    371 _AMX0N	=	0x00ba
                    00BB    372 G$AMX0P$0$0 == 0x00bb
                    00BB    373 _AMX0P	=	0x00bb
                    00BC    374 G$ADC0CF$0$0 == 0x00bc
                    00BC    375 _ADC0CF	=	0x00bc
                    00BD    376 G$ADC0L$0$0 == 0x00bd
                    00BD    377 _ADC0L	=	0x00bd
                    00BE    378 G$ADC0H$0$0 == 0x00be
                    00BE    379 _ADC0H	=	0x00be
                    00C0    380 G$SMB0CN$0$0 == 0x00c0
                    00C0    381 _SMB0CN	=	0x00c0
                    00C1    382 G$SMB0CF$0$0 == 0x00c1
                    00C1    383 _SMB0CF	=	0x00c1
                    00C2    384 G$SMB0DAT$0$0 == 0x00c2
                    00C2    385 _SMB0DAT	=	0x00c2
                    00C3    386 G$ADC0GTL$0$0 == 0x00c3
                    00C3    387 _ADC0GTL	=	0x00c3
                    00C4    388 G$ADC0GTH$0$0 == 0x00c4
                    00C4    389 _ADC0GTH	=	0x00c4
                    00C5    390 G$ADC0LTL$0$0 == 0x00c5
                    00C5    391 _ADC0LTL	=	0x00c5
                    00C6    392 G$ADC0LTH$0$0 == 0x00c6
                    00C6    393 _ADC0LTH	=	0x00c6
                    00C8    394 G$TMR2CN$0$0 == 0x00c8
                    00C8    395 _TMR2CN	=	0x00c8
                    00C9    396 G$REG0CN$0$0 == 0x00c9
                    00C9    397 _REG0CN	=	0x00c9
                    00CA    398 G$TMR2RLL$0$0 == 0x00ca
                    00CA    399 _TMR2RLL	=	0x00ca
                    00CB    400 G$TMR2RLH$0$0 == 0x00cb
                    00CB    401 _TMR2RLH	=	0x00cb
                    00CC    402 G$TMR2L$0$0 == 0x00cc
                    00CC    403 _TMR2L	=	0x00cc
                    00CD    404 G$TMR2H$0$0 == 0x00cd
                    00CD    405 _TMR2H	=	0x00cd
                    00D0    406 G$PSW$0$0 == 0x00d0
                    00D0    407 _PSW	=	0x00d0
                    00D1    408 G$REF0CN$0$0 == 0x00d1
                    00D1    409 _REF0CN	=	0x00d1
                    00D4    410 G$P0SKIP$0$0 == 0x00d4
                    00D4    411 _P0SKIP	=	0x00d4
                    00D5    412 G$P1SKIP$0$0 == 0x00d5
                    00D5    413 _P1SKIP	=	0x00d5
                    00D6    414 G$P2SKIP$0$0 == 0x00d6
                    00D6    415 _P2SKIP	=	0x00d6
                    00D7    416 G$USB0XCN$0$0 == 0x00d7
                    00D7    417 _USB0XCN	=	0x00d7
                    00D8    418 G$PCA0CN$0$0 == 0x00d8
                    00D8    419 _PCA0CN	=	0x00d8
                    00D9    420 G$PCA0MD$0$0 == 0x00d9
                    00D9    421 _PCA0MD	=	0x00d9
                    00DA    422 G$PCA0CPM0$0$0 == 0x00da
                    00DA    423 _PCA0CPM0	=	0x00da
                    00DB    424 G$PCA0CPM1$0$0 == 0x00db
                    00DB    425 _PCA0CPM1	=	0x00db
                    00DC    426 G$PCA0CPM2$0$0 == 0x00dc
                    00DC    427 _PCA0CPM2	=	0x00dc
                    00DD    428 G$PCA0CPM3$0$0 == 0x00dd
                    00DD    429 _PCA0CPM3	=	0x00dd
                    00DE    430 G$PCA0CPM4$0$0 == 0x00de
                    00DE    431 _PCA0CPM4	=	0x00de
                    00E0    432 G$ACC$0$0 == 0x00e0
                    00E0    433 _ACC	=	0x00e0
                    00E1    434 G$XBR0$0$0 == 0x00e1
                    00E1    435 _XBR0	=	0x00e1
                    00E2    436 G$XBR1$0$0 == 0x00e2
                    00E2    437 _XBR1	=	0x00e2
                    00E4    438 G$IT01CF$0$0 == 0x00e4
                    00E4    439 _IT01CF	=	0x00e4
                    00E6    440 G$EIE1$0$0 == 0x00e6
                    00E6    441 _EIE1	=	0x00e6
                    00E7    442 G$EIE2$0$0 == 0x00e7
                    00E7    443 _EIE2	=	0x00e7
                    00E8    444 G$ADC0CN$0$0 == 0x00e8
                    00E8    445 _ADC0CN	=	0x00e8
                    00E9    446 G$PCA0CPL1$0$0 == 0x00e9
                    00E9    447 _PCA0CPL1	=	0x00e9
                    00EA    448 G$PCA0CPH1$0$0 == 0x00ea
                    00EA    449 _PCA0CPH1	=	0x00ea
                    00EB    450 G$PCA0CPL2$0$0 == 0x00eb
                    00EB    451 _PCA0CPL2	=	0x00eb
                    00EC    452 G$PCA0CPH2$0$0 == 0x00ec
                    00EC    453 _PCA0CPH2	=	0x00ec
                    00ED    454 G$PCA0CPL3$0$0 == 0x00ed
                    00ED    455 _PCA0CPL3	=	0x00ed
                    00EE    456 G$PCA0CPH3$0$0 == 0x00ee
                    00EE    457 _PCA0CPH3	=	0x00ee
                    00EF    458 G$RSTSRC$0$0 == 0x00ef
                    00EF    459 _RSTSRC	=	0x00ef
                    00F0    460 G$B$0$0 == 0x00f0
                    00F0    461 _B	=	0x00f0
                    00F1    462 G$P0MDIN$0$0 == 0x00f1
                    00F1    463 _P0MDIN	=	0x00f1
                    00F2    464 G$P1MDIN$0$0 == 0x00f2
                    00F2    465 _P1MDIN	=	0x00f2
                    00F3    466 G$P2MDIN$0$0 == 0x00f3
                    00F3    467 _P2MDIN	=	0x00f3
                    00F4    468 G$P3MDIN$0$0 == 0x00f4
                    00F4    469 _P3MDIN	=	0x00f4
                    00F6    470 G$EIP1$0$0 == 0x00f6
                    00F6    471 _EIP1	=	0x00f6
                    00F7    472 G$EIP2$0$0 == 0x00f7
                    00F7    473 _EIP2	=	0x00f7
                    00F8    474 G$SPI0CN$0$0 == 0x00f8
                    00F8    475 _SPI0CN	=	0x00f8
                    00F9    476 G$PCA0L$0$0 == 0x00f9
                    00F9    477 _PCA0L	=	0x00f9
                    00FA    478 G$PCA0H$0$0 == 0x00fa
                    00FA    479 _PCA0H	=	0x00fa
                    00FB    480 G$PCA0CPL0$0$0 == 0x00fb
                    00FB    481 _PCA0CPL0	=	0x00fb
                    00FC    482 G$PCA0CPH0$0$0 == 0x00fc
                    00FC    483 _PCA0CPH0	=	0x00fc
                    00FD    484 G$PCA0CPL4$0$0 == 0x00fd
                    00FD    485 _PCA0CPL4	=	0x00fd
                    00FE    486 G$PCA0CPH4$0$0 == 0x00fe
                    00FE    487 _PCA0CPH4	=	0x00fe
                    00FF    488 G$VDM0CN$0$0 == 0x00ff
                    00FF    489 _VDM0CN	=	0x00ff
                    8382    490 G$DP$0$0 == 0x8382
                    8382    491 _DP	=	0x8382
                    9392    492 G$TMR3RL$0$0 == 0x9392
                    9392    493 _TMR3RL	=	0x9392
                    9594    494 G$TMR3$0$0 == 0x9594
                    9594    495 _TMR3	=	0x9594
                    BEBD    496 G$ADC0$0$0 == 0xbebd
                    BEBD    497 _ADC0	=	0xbebd
                    C4C3    498 G$ADC0GT$0$0 == 0xc4c3
                    C4C3    499 _ADC0GT	=	0xc4c3
                    C6C5    500 G$ADC0LT$0$0 == 0xc6c5
                    C6C5    501 _ADC0LT	=	0xc6c5
                    CBCA    502 G$TMR2RL$0$0 == 0xcbca
                    CBCA    503 _TMR2RL	=	0xcbca
                    CDCC    504 G$TMR2$0$0 == 0xcdcc
                    CDCC    505 _TMR2	=	0xcdcc
                    EAE9    506 G$PCA0CP1$0$0 == 0xeae9
                    EAE9    507 _PCA0CP1	=	0xeae9
                    ECEB    508 G$PCA0CP2$0$0 == 0xeceb
                    ECEB    509 _PCA0CP2	=	0xeceb
                    EEED    510 G$PCA0CP3$0$0 == 0xeeed
                    EEED    511 _PCA0CP3	=	0xeeed
                    FAF9    512 G$PCA0$0$0 == 0xfaf9
                    FAF9    513 _PCA0	=	0xfaf9
                    FCFB    514 G$PCA0CP0$0$0 == 0xfcfb
                    FCFB    515 _PCA0CP0	=	0xfcfb
                    FEFD    516 G$PCA0CP4$0$0 == 0xfefd
                    FEFD    517 _PCA0CP4	=	0xfefd
                            518 ;--------------------------------------------------------
                            519 ; special function bits
                            520 ;--------------------------------------------------------
                            521 	.area RSEG    (ABS,DATA)
   0000                     522 	.org 0x0000
                    008F    523 G$TF1$0$0 == 0x008f
                    008F    524 _TF1	=	0x008f
                    008E    525 G$TR1$0$0 == 0x008e
                    008E    526 _TR1	=	0x008e
                    008D    527 G$TF0$0$0 == 0x008d
                    008D    528 _TF0	=	0x008d
                    008C    529 G$TR0$0$0 == 0x008c
                    008C    530 _TR0	=	0x008c
                    008B    531 G$IE1$0$0 == 0x008b
                    008B    532 _IE1	=	0x008b
                    008A    533 G$IT1$0$0 == 0x008a
                    008A    534 _IT1	=	0x008a
                    0089    535 G$IE0$0$0 == 0x0089
                    0089    536 _IE0	=	0x0089
                    0088    537 G$IT0$0$0 == 0x0088
                    0088    538 _IT0	=	0x0088
                    009F    539 G$S0MODE$0$0 == 0x009f
                    009F    540 _S0MODE	=	0x009f
                    009D    541 G$MCE0$0$0 == 0x009d
                    009D    542 _MCE0	=	0x009d
                    009C    543 G$REN0$0$0 == 0x009c
                    009C    544 _REN0	=	0x009c
                    009B    545 G$TB80$0$0 == 0x009b
                    009B    546 _TB80	=	0x009b
                    009A    547 G$RB80$0$0 == 0x009a
                    009A    548 _RB80	=	0x009a
                    0099    549 G$TI0$0$0 == 0x0099
                    0099    550 _TI0	=	0x0099
                    0098    551 G$RI0$0$0 == 0x0098
                    0098    552 _RI0	=	0x0098
                    00AF    553 G$EA$0$0 == 0x00af
                    00AF    554 _EA	=	0x00af
                    00AE    555 G$ESPI0$0$0 == 0x00ae
                    00AE    556 _ESPI0	=	0x00ae
                    00AD    557 G$ET2$0$0 == 0x00ad
                    00AD    558 _ET2	=	0x00ad
                    00AC    559 G$ES0$0$0 == 0x00ac
                    00AC    560 _ES0	=	0x00ac
                    00AB    561 G$ET1$0$0 == 0x00ab
                    00AB    562 _ET1	=	0x00ab
                    00AA    563 G$EX1$0$0 == 0x00aa
                    00AA    564 _EX1	=	0x00aa
                    00A9    565 G$ET0$0$0 == 0x00a9
                    00A9    566 _ET0	=	0x00a9
                    00A8    567 G$EX0$0$0 == 0x00a8
                    00A8    568 _EX0	=	0x00a8
                    00BE    569 G$PSPI0$0$0 == 0x00be
                    00BE    570 _PSPI0	=	0x00be
                    00BD    571 G$PT2$0$0 == 0x00bd
                    00BD    572 _PT2	=	0x00bd
                    00BC    573 G$PS0$0$0 == 0x00bc
                    00BC    574 _PS0	=	0x00bc
                    00BB    575 G$PT1$0$0 == 0x00bb
                    00BB    576 _PT1	=	0x00bb
                    00BA    577 G$PX1$0$0 == 0x00ba
                    00BA    578 _PX1	=	0x00ba
                    00B9    579 G$PT0$0$0 == 0x00b9
                    00B9    580 _PT0	=	0x00b9
                    00B8    581 G$PX0$0$0 == 0x00b8
                    00B8    582 _PX0	=	0x00b8
                    00C7    583 G$MASTER$0$0 == 0x00c7
                    00C7    584 _MASTER	=	0x00c7
                    00C6    585 G$TXMODE$0$0 == 0x00c6
                    00C6    586 _TXMODE	=	0x00c6
                    00C5    587 G$STA$0$0 == 0x00c5
                    00C5    588 _STA	=	0x00c5
                    00C4    589 G$STO$0$0 == 0x00c4
                    00C4    590 _STO	=	0x00c4
                    00C3    591 G$ACKRQ$0$0 == 0x00c3
                    00C3    592 _ACKRQ	=	0x00c3
                    00C2    593 G$ARBLOST$0$0 == 0x00c2
                    00C2    594 _ARBLOST	=	0x00c2
                    00C1    595 G$ACK$0$0 == 0x00c1
                    00C1    596 _ACK	=	0x00c1
                    00C0    597 G$SI$0$0 == 0x00c0
                    00C0    598 _SI	=	0x00c0
                    00CF    599 G$TF2H$0$0 == 0x00cf
                    00CF    600 _TF2H	=	0x00cf
                    00CE    601 G$TF2L$0$0 == 0x00ce
                    00CE    602 _TF2L	=	0x00ce
                    00CD    603 G$TF2LEN$0$0 == 0x00cd
                    00CD    604 _TF2LEN	=	0x00cd
                    00CC    605 G$T2SOF$0$0 == 0x00cc
                    00CC    606 _T2SOF	=	0x00cc
                    00CB    607 G$T2SPLIT$0$0 == 0x00cb
                    00CB    608 _T2SPLIT	=	0x00cb
                    00CA    609 G$TR2$0$0 == 0x00ca
                    00CA    610 _TR2	=	0x00ca
                    00C8    611 G$T2XCLK$0$0 == 0x00c8
                    00C8    612 _T2XCLK	=	0x00c8
                    00D7    613 G$CY$0$0 == 0x00d7
                    00D7    614 _CY	=	0x00d7
                    00D6    615 G$AC$0$0 == 0x00d6
                    00D6    616 _AC	=	0x00d6
                    00D5    617 G$F0$0$0 == 0x00d5
                    00D5    618 _F0	=	0x00d5
                    00D4    619 G$RS1$0$0 == 0x00d4
                    00D4    620 _RS1	=	0x00d4
                    00D3    621 G$RS0$0$0 == 0x00d3
                    00D3    622 _RS0	=	0x00d3
                    00D2    623 G$OV$0$0 == 0x00d2
                    00D2    624 _OV	=	0x00d2
                    00D1    625 G$F1$0$0 == 0x00d1
                    00D1    626 _F1	=	0x00d1
                    00D0    627 G$P$0$0 == 0x00d0
                    00D0    628 _P	=	0x00d0
                    00DF    629 G$CF$0$0 == 0x00df
                    00DF    630 _CF	=	0x00df
                    00DE    631 G$CR$0$0 == 0x00de
                    00DE    632 _CR	=	0x00de
                    00DC    633 G$CCF4$0$0 == 0x00dc
                    00DC    634 _CCF4	=	0x00dc
                    00DB    635 G$CCF3$0$0 == 0x00db
                    00DB    636 _CCF3	=	0x00db
                    00DA    637 G$CCF2$0$0 == 0x00da
                    00DA    638 _CCF2	=	0x00da
                    00D9    639 G$CCF1$0$0 == 0x00d9
                    00D9    640 _CCF1	=	0x00d9
                    00D8    641 G$CCF0$0$0 == 0x00d8
                    00D8    642 _CCF0	=	0x00d8
                    00EF    643 G$AD0EN$0$0 == 0x00ef
                    00EF    644 _AD0EN	=	0x00ef
                    00EE    645 G$AD0TM$0$0 == 0x00ee
                    00EE    646 _AD0TM	=	0x00ee
                    00ED    647 G$AD0INT$0$0 == 0x00ed
                    00ED    648 _AD0INT	=	0x00ed
                    00EC    649 G$AD0BUSY$0$0 == 0x00ec
                    00EC    650 _AD0BUSY	=	0x00ec
                    00EB    651 G$AD0WINT$0$0 == 0x00eb
                    00EB    652 _AD0WINT	=	0x00eb
                    00EA    653 G$AD0CM2$0$0 == 0x00ea
                    00EA    654 _AD0CM2	=	0x00ea
                    00E9    655 G$AD0CM1$0$0 == 0x00e9
                    00E9    656 _AD0CM1	=	0x00e9
                    00E8    657 G$AD0CM0$0$0 == 0x00e8
                    00E8    658 _AD0CM0	=	0x00e8
                    00FF    659 G$SPIF$0$0 == 0x00ff
                    00FF    660 _SPIF	=	0x00ff
                    00FE    661 G$WCOL$0$0 == 0x00fe
                    00FE    662 _WCOL	=	0x00fe
                    00FD    663 G$MODF$0$0 == 0x00fd
                    00FD    664 _MODF	=	0x00fd
                    00FC    665 G$RXOVRN$0$0 == 0x00fc
                    00FC    666 _RXOVRN	=	0x00fc
                    00FB    667 G$NSSMD1$0$0 == 0x00fb
                    00FB    668 _NSSMD1	=	0x00fb
                    00FA    669 G$NSSMD0$0$0 == 0x00fa
                    00FA    670 _NSSMD0	=	0x00fa
                    00F9    671 G$TXBMT$0$0 == 0x00f9
                    00F9    672 _TXBMT	=	0x00f9
                    00F8    673 G$SPIEN$0$0 == 0x00f8
                    00F8    674 _SPIEN	=	0x00f8
                    0083    675 G$M2DIR$0$0 == 0x0083
                    0083    676 _M2DIR	=	0x0083
                    0084    677 G$M2STEP$0$0 == 0x0084
                    0084    678 _M2STEP	=	0x0084
                    0085    679 G$NDRIVEREN$0$0 == 0x0085
                    0085    680 _NDRIVEREN	=	0x0085
                    0096    681 G$M1DIR$0$0 == 0x0096
                    0096    682 _M1DIR	=	0x0096
                    0087    683 G$M1STEP$0$0 == 0x0087
                    0087    684 _M1STEP	=	0x0087
                    0090    685 G$INTTL$0$0 == 0x0090
                    0090    686 _INTTL	=	0x0090
                    0091    687 G$OUTTTL$0$0 == 0x0091
                    0091    688 _OUTTTL	=	0x0091
                    0092    689 G$LASER$0$0 == 0x0092
                    0092    690 _LASER	=	0x0092
                    0094    691 G$NDACCS$0$0 == 0x0094
                    0094    692 _NDACCS	=	0x0094
                    0097    693 G$CAL$0$0 == 0x0097
                    0097    694 _CAL	=	0x0097
                    00A0    695 G$POS$0$0 == 0x00a0
                    00A0    696 _POS	=	0x00a0
                    00A1    697 G$NADCCS$0$0 == 0x00a1
                    00A1    698 _NADCCS	=	0x00a1
                    00A3    699 G$OUTPUTEN$0$0 == 0x00a3
                    00A3    700 _OUTPUTEN	=	0x00a3
                    00A6    701 G$NRAMCS$0$0 == 0x00a6
                    00A6    702 _NRAMCS	=	0x00a6
                    00A7    703 G$NRAMHOLD$0$0 == 0x00a7
                    00A7    704 _NRAMHOLD	=	0x00a7
                    00A2    705 G$ERRORPIN$0$0 == 0x00a2
                    00A2    706 _ERRORPIN	=	0x00a2
                    0085    707 G$NotDriverEN$0$0 == 0x0085
                    0085    708 _NotDriverEN	=	0x0085
                    0086    709 G$Motor1Dir$0$0 == 0x0086
                    0086    710 _Motor1Dir	=	0x0086
                    0087    711 G$Motor1Step$0$0 == 0x0087
                    0087    712 _Motor1Step	=	0x0087
                    0083    713 G$Motor2Dir$0$0 == 0x0083
                    0083    714 _Motor2Dir	=	0x0083
                    0084    715 G$Motor2Step$0$0 == 0x0084
                    0084    716 _Motor2Step	=	0x0084
                            717 ;--------------------------------------------------------
                            718 ; overlayable register banks
                            719 ;--------------------------------------------------------
                            720 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     721 	.ds 8
                            722 ;--------------------------------------------------------
                            723 ; internal ram data
                            724 ;--------------------------------------------------------
                            725 	.area DSEG    (DATA)
                    0000    726 G$Writing_to_DAC$0$0==.
   0008                     727 _Writing_to_DAC::
   0008                     728 	.ds 2
                    0002    729 G$Writing_to_ADC$0$0==.
   000A                     730 _Writing_to_ADC::
   000A                     731 	.ds 2
                    0004    732 G$Writing_to_RAM$0$0==.
   000C                     733 _Writing_to_RAM::
   000C                     734 	.ds 2
                    0006    735 G$SPI_DAC_Bytes$0$0==.
   000E                     736 _SPI_DAC_Bytes::
   000E                     737 	.ds 2
                    0008    738 G$SPI_ADC_Bytes$0$0==.
   0010                     739 _SPI_ADC_Bytes::
   0010                     740 	.ds 2
                    000A    741 G$SPI_RAM_Bytes$0$0==.
   0012                     742 _SPI_RAM_Bytes::
   0012                     743 	.ds 2
                    000C    744 G$ADC_timer$0$0==.
   0014                     745 _ADC_timer::
   0014                     746 	.ds 2
                    000E    747 G$ADC_settled$0$0==.
   0016                     748 _ADC_settled::
   0016                     749 	.ds 2
                    0010    750 G$ADC_timer_MSB$0$0==.
   0018                     751 _ADC_timer_MSB::
   0018                     752 	.ds 2
                    0012    753 G$latest_ADC_HighByte$0$0==.
   001A                     754 _latest_ADC_HighByte::
   001A                     755 	.ds 2
                    0014    756 G$latest_ADC_LowByte$0$0==.
   001C                     757 _latest_ADC_LowByte::
   001C                     758 	.ds 2
                    0016    759 G$Write_to_RAM$0$0==.
   001E                     760 _Write_to_RAM::
   001E                     761 	.ds 2
                    0018    762 G$RAM_to_ptr_low$0$0==.
   0020                     763 _RAM_to_ptr_low::
   0020                     764 	.ds 1
                    0019    765 G$RAM_to_ptr_high$0$0==.
   0021                     766 _RAM_to_ptr_high::
   0021                     767 	.ds 1
                    001A    768 G$RAM_from_ptr_low$0$0==.
   0022                     769 _RAM_from_ptr_low::
   0022                     770 	.ds 1
                    001B    771 G$RAM_from_ptr_high$0$0==.
   0023                     772 _RAM_from_ptr_high::
   0023                     773 	.ds 1
                    001C    774 G$loop_cnt$0$0==.
   0024                     775 _loop_cnt::
   0024                     776 	.ds 2
                            777 ;--------------------------------------------------------
                            778 ; overlayable items in internal ram 
                            779 ;--------------------------------------------------------
                            780 	.area	OSEG    (OVR,DATA)
                            781 	.area	OSEG    (OVR,DATA)
                            782 ;--------------------------------------------------------
                            783 ; Stack segment in internal ram 
                            784 ;--------------------------------------------------------
                            785 	.area	SSEG	(DATA)
   0026                     786 __start__stack:
   0026                     787 	.ds	1
                            788 
                            789 ;--------------------------------------------------------
                            790 ; indirectly addressable internal ram data
                            791 ;--------------------------------------------------------
                            792 	.area ISEG    (DATA)
                            793 ;--------------------------------------------------------
                            794 ; absolute internal ram data
                            795 ;--------------------------------------------------------
                            796 	.area IABS    (ABS,DATA)
                            797 	.area IABS    (ABS,DATA)
                            798 ;--------------------------------------------------------
                            799 ; bit data
                            800 ;--------------------------------------------------------
                            801 	.area BSEG    (BIT)
                            802 ;--------------------------------------------------------
                            803 ; paged external ram data
                            804 ;--------------------------------------------------------
                            805 	.area PSEG    (PAG,XDATA)
                            806 ;--------------------------------------------------------
                            807 ; external ram data
                            808 ;--------------------------------------------------------
                            809 	.area XSEG    (XDATA)
                            810 ;--------------------------------------------------------
                            811 ; absolute external ram data
                            812 ;--------------------------------------------------------
                            813 	.area XABS    (ABS,XDATA)
                            814 ;--------------------------------------------------------
                            815 ; external initialized ram data
                            816 ;--------------------------------------------------------
                            817 	.area XISEG   (XDATA)
                            818 	.area HOME    (CODE)
                            819 	.area GSINIT0 (CODE)
                            820 	.area GSINIT1 (CODE)
                            821 	.area GSINIT2 (CODE)
                            822 	.area GSINIT3 (CODE)
                            823 	.area GSINIT4 (CODE)
                            824 	.area GSINIT5 (CODE)
                            825 	.area GSINIT  (CODE)
                            826 	.area GSFINAL (CODE)
                            827 	.area CSEG    (CODE)
                            828 ;--------------------------------------------------------
                            829 ; interrupt vector 
                            830 ;--------------------------------------------------------
                            831 	.area HOME    (CODE)
   0000                     832 __interrupt_vect:
   0000 02 00 3B            833 	ljmp	__sdcc_gsinit_startup
   0003 32                  834 	reti
   0004                     835 	.ds	7
   000B 32                  836 	reti
   000C                     837 	.ds	7
   0013 32                  838 	reti
   0014                     839 	.ds	7
   001B 02 04 0C            840 	ljmp	_Timer1_ISR
   001E                     841 	.ds	5
   0023 32                  842 	reti
   0024                     843 	.ds	7
   002B 02 04 F1            844 	ljmp	_Timer2_ISR
   002E                     845 	.ds	5
   0033 02 03 59            846 	ljmp	_SPI_ISR
                            847 ;--------------------------------------------------------
                            848 ; global & static initialisations
                            849 ;--------------------------------------------------------
                            850 	.area HOME    (CODE)
                            851 	.area GSINIT  (CODE)
                            852 	.area GSFINAL (CODE)
                            853 	.area GSINIT  (CODE)
                            854 	.globl __sdcc_gsinit_startup
                            855 	.globl __sdcc_program_startup
                            856 	.globl __start__stack
                            857 	.globl __mcs51_genXINIT
                            858 	.globl __mcs51_genXRAMCLEAR
                            859 	.globl __mcs51_genRAMCLEAR
                    0000    860 	G$Timer2_ISR$0$0 ==.
                    0000    861 	C$potentiostat_HWtestingMain.c$86$1$1 ==.
                            862 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:86: int Writing_to_DAC = 0;					// Boolean: still need to write >=1 byte via SPI
   0094 E4                  863 	clr	a
   0095 F5 08               864 	mov	_Writing_to_DAC,a
   0097 F5 09               865 	mov	(_Writing_to_DAC + 1),a
                    0005    866 	G$Timer2_ISR$0$0 ==.
                    0005    867 	C$potentiostat_HWtestingMain.c$87$1$1 ==.
                            868 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:87: int Writing_to_ADC = 0;					// Boolean: still need to write >=1 byte via SPI
   0099 E4                  869 	clr	a
   009A F5 0A               870 	mov	_Writing_to_ADC,a
   009C F5 0B               871 	mov	(_Writing_to_ADC + 1),a
                    000A    872 	G$Timer2_ISR$0$0 ==.
                    000A    873 	C$potentiostat_HWtestingMain.c$88$1$1 ==.
                            874 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:88: int Writing_to_RAM = 0;					// Boolean: still need to write >=1 byte via SPI
   009E E4                  875 	clr	a
   009F F5 0C               876 	mov	_Writing_to_RAM,a
   00A1 F5 0D               877 	mov	(_Writing_to_RAM + 1),a
                    000F    878 	G$Timer2_ISR$0$0 ==.
                    000F    879 	C$potentiostat_HWtestingMain.c$89$1$1 ==.
                            880 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:89: int SPI_DAC_Bytes = 0;					// No. of bytes to/from DAC: 0-3
   00A3 E4                  881 	clr	a
   00A4 F5 0E               882 	mov	_SPI_DAC_Bytes,a
   00A6 F5 0F               883 	mov	(_SPI_DAC_Bytes + 1),a
                    0014    884 	G$Timer2_ISR$0$0 ==.
                    0014    885 	C$potentiostat_HWtestingMain.c$90$1$1 ==.
                            886 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:90: int SPI_ADC_Bytes = 0;					// No. of bytes to/from ADC: 0-2
   00A8 E4                  887 	clr	a
   00A9 F5 10               888 	mov	_SPI_ADC_Bytes,a
   00AB F5 11               889 	mov	(_SPI_ADC_Bytes + 1),a
                    0019    890 	G$Timer2_ISR$0$0 ==.
                    0019    891 	C$potentiostat_HWtestingMain.c$91$1$1 ==.
                            892 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:91: int SPI_RAM_Bytes = 0;					// No. of bytes to/from RAM: 0-4
   00AD E4                  893 	clr	a
   00AE F5 12               894 	mov	_SPI_RAM_Bytes,a
   00B0 F5 13               895 	mov	(_SPI_RAM_Bytes + 1),a
                    001E    896 	G$Timer2_ISR$0$0 ==.
                    001E    897 	C$potentiostat_HWtestingMain.c$92$1$1 ==.
                            898 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:92: int ADC_timer = 0;						// No. of 1 ms timer intervals after ADC turn on
   00B2 E4                  899 	clr	a
   00B3 F5 14               900 	mov	_ADC_timer,a
   00B5 F5 15               901 	mov	(_ADC_timer + 1),a
                    0023    902 	G$Timer2_ISR$0$0 ==.
                    0023    903 	C$potentiostat_HWtestingMain.c$93$1$1 ==.
                            904 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:93: int ADC_settled = 0;					// Boolean: ADC ready 12 ms after POR
   00B7 E4                  905 	clr	a
   00B8 F5 16               906 	mov	_ADC_settled,a
   00BA F5 17               907 	mov	(_ADC_settled + 1),a
                    0028    908 	G$Timer2_ISR$0$0 ==.
                    0028    909 	C$potentiostat_HWtestingMain.c$94$1$1 ==.
                            910 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:94: int ADC_timer_MSB = 0;					// Software bit to ADC timer
   00BC E4                  911 	clr	a
   00BD F5 18               912 	mov	_ADC_timer_MSB,a
   00BF F5 19               913 	mov	(_ADC_timer_MSB + 1),a
                    002D    914 	G$Timer2_ISR$0$0 ==.
                    002D    915 	C$potentiostat_HWtestingMain.c$97$1$1 ==.
                            916 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:97: int Write_to_RAM = 0;					// Boolean: need to write ADC to RAM
   00C1 E4                  917 	clr	a
   00C2 F5 1E               918 	mov	_Write_to_RAM,a
   00C4 F5 1F               919 	mov	(_Write_to_RAM + 1),a
                    0032    920 	G$Timer2_ISR$0$0 ==.
                    0032    921 	C$potentiostat_HWtestingMain.c$104$1$1 ==.
                            922 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:104: int loop_cnt = 0;
   00C6 E4                  923 	clr	a
   00C7 F5 24               924 	mov	_loop_cnt,a
   00C9 F5 25               925 	mov	(_loop_cnt + 1),a
                            926 	.area GSFINAL (CODE)
   00CB 02 00 36            927 	ljmp	__sdcc_program_startup
                            928 ;--------------------------------------------------------
                            929 ; Home
                            930 ;--------------------------------------------------------
                            931 	.area HOME    (CODE)
                            932 	.area HOME    (CODE)
   0036                     933 __sdcc_program_startup:
   0036 12 00 CE            934 	lcall	_main
                            935 ;	return from main will lock up
   0039 80 FE               936 	sjmp .
                            937 ;--------------------------------------------------------
                            938 ; code
                            939 ;--------------------------------------------------------
                            940 	.area CSEG    (CODE)
                            941 ;------------------------------------------------------------
                            942 ;Allocation info for local variables in function 'main'
                            943 ;------------------------------------------------------------
                            944 ;------------------------------------------------------------
                    0000    945 	G$main$0$0 ==.
                    0000    946 	C$potentiostat_HWtestingMain.c$109$0$0 ==.
                            947 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:109: void main (void)
                            948 ;	-----------------------------------------
                            949 ;	 function main
                            950 ;	-----------------------------------------
   00CE                     951 _main:
                    0002    952 	ar2 = 0x02
                    0003    953 	ar3 = 0x03
                    0004    954 	ar4 = 0x04
                    0005    955 	ar5 = 0x05
                    0006    956 	ar6 = 0x06
                    0007    957 	ar7 = 0x07
                    0000    958 	ar0 = 0x00
                    0001    959 	ar1 = 0x01
                    0000    960 	C$potentiostat_HWtestingMain.c$111$1$1 ==.
                            961 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:111: PCA0MD &= ~0x40;					// Disable watchdog timer
   00CE 53 D9 BF            962 	anl	_PCA0MD,#0xBF
                    0003    963 	C$potentiostat_HWtestingMain.c$113$1$1 ==.
                            964 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:113: ERRORPIN = 0;
   00D1 C2 A2               965 	clr	_ERRORPIN
                    0005    966 	C$potentiostat_HWtestingMain.c$114$1$1 ==.
                            967 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:114: latest_ADC_LowByte = 0;
                    0005    968 	C$potentiostat_HWtestingMain.c$115$1$1 ==.
                            969 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:115: latest_ADC_HighByte = 0;
   00D3 E4                  970 	clr	a
   00D4 F5 1C               971 	mov	_latest_ADC_LowByte,a
   00D6 F5 1D               972 	mov	(_latest_ADC_LowByte + 1),a
   00D8 F5 1A               973 	mov	_latest_ADC_HighByte,a
   00DA F5 1B               974 	mov	(_latest_ADC_HighByte + 1),a
                    000E    975 	C$potentiostat_HWtestingMain.c$117$1$1 ==.
                            976 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:117: SYSCLK_Init ();					// Initialize system clock to 24 MHz
   00DC 12 01 79            977 	lcall	_SYSCLK_Init
                    0011    978 	C$potentiostat_HWtestingMain.c$120$1$1 ==.
                            979 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:120: Timer1_Init();					// Start the 1 kHz ADC timer
   00DF 12 01 F1            980 	lcall	_Timer1_Init
                    0014    981 	C$potentiostat_HWtestingMain.c$122$1$1 ==.
                            982 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:122: PORT_Init ();					// Initialize crossbar and GPIO
   00E2 12 01 AF            983 	lcall	_PORT_Init
                    0017    984 	C$potentiostat_HWtestingMain.c$126$1$1 ==.
                            985 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:126: EA = 1;							// Enable global interrupts
   00E5 D2 AF               986 	setb	_EA
                    0019    987 	C$potentiostat_HWtestingMain.c$128$1$1 ==.
                            988 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:128: SPI_Init();						// Set up SPI peripheral
   00E7 12 02 2D            989 	lcall	_SPI_Init
                    001C    990 	C$potentiostat_HWtestingMain.c$129$1$1 ==.
                            991 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:129: DAC_Init();						// Call just after SPI_Init for proper function
   00EA 12 02 3F            992 	lcall	_DAC_Init
                    001F    993 	C$potentiostat_HWtestingMain.c$131$1$1 ==.
                            994 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:131: OUTPUTEN = 1;					// emable output, close relay K601
   00ED D2 A3               995 	setb	_OUTPUTEN
                    0021    996 	C$potentiostat_HWtestingMain.c$132$1$1 ==.
                            997 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:132: CAL = 0;
   00EF C2 97               998 	clr	_CAL
                    0023    999 	C$potentiostat_HWtestingMain.c$151$1$1 ==.
                           1000 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:151: POS = 1;
   00F1 D2 A0              1001 	setb	_POS
                    0025   1002 	C$potentiostat_HWtestingMain.c$152$1$1 ==.
                           1003 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:152: NDACCS = 0;						// Select the DAC for SPI communication
   00F3 C2 94              1004 	clr	_NDACCS
                    0027   1005 	C$potentiostat_HWtestingMain.c$153$1$1 ==.
                           1006 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:153: Writing_to_DAC = 1;
   00F5 75 08 01           1007 	mov	_Writing_to_DAC,#0x01
   00F8 75 09 00           1008 	mov	(_Writing_to_DAC + 1),#0x00
                    002D   1009 	C$potentiostat_HWtestingMain.c$154$1$1 ==.
                           1010 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:154: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   00FB 75 A3 00           1011 	mov	_SPI0DAT,#0x00
                    0030   1012 	C$potentiostat_HWtestingMain.c$155$1$1 ==.
                           1013 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:155: while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
   00FE                    1014 00101$:
   00FE 74 01              1015 	mov	a,#0x01
   0100 B5 0E 06           1016 	cjne	a,_SPI_DAC_Bytes,00135$
   0103 E4                 1017 	clr	a
   0104 B5 0F 02           1018 	cjne	a,(_SPI_DAC_Bytes + 1),00135$
   0107 80 02              1019 	sjmp	00136$
   0109                    1020 00135$:
   0109 80 F3              1021 	sjmp	00101$
   010B                    1022 00136$:
                    003D   1023 	C$potentiostat_HWtestingMain.c$158$1$1 ==.
                           1024 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:158: SPI0DAT = 0xFE;					// Upper part of byte
   010B 75 A3 FE           1025 	mov	_SPI0DAT,#0xFE
                    0040   1026 	C$potentiostat_HWtestingMain.c$159$1$1 ==.
                           1027 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:159: while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
   010E                    1028 00104$:
   010E 74 02              1029 	mov	a,#0x02
   0110 B5 0E 06           1030 	cjne	a,_SPI_DAC_Bytes,00137$
   0113 E4                 1031 	clr	a
   0114 B5 0F 02           1032 	cjne	a,(_SPI_DAC_Bytes + 1),00137$
   0117 80 02              1033 	sjmp	00138$
   0119                    1034 00137$:
   0119 80 F3              1035 	sjmp	00104$
   011B                    1036 00138$:
                    004D   1037 	C$potentiostat_HWtestingMain.c$162$1$1 ==.
                           1038 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:162: SPI0DAT = 0xB8;					// Lower part of byte
   011B 75 A3 B8           1039 	mov	_SPI0DAT,#0xB8
                    0050   1040 	C$potentiostat_HWtestingMain.c$163$1$1 ==.
                           1041 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:163: while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
   011E                    1042 00107$:
   011E 74 03              1043 	mov	a,#0x03
   0120 B5 0E 06           1044 	cjne	a,_SPI_DAC_Bytes,00139$
   0123 E4                 1045 	clr	a
   0124 B5 0F 02           1046 	cjne	a,(_SPI_DAC_Bytes + 1),00139$
   0127 80 02              1047 	sjmp	00140$
   0129                    1048 00139$:
   0129 80 F3              1049 	sjmp	00107$
   012B                    1050 00140$:
                    005D   1051 	C$potentiostat_HWtestingMain.c$164$1$1 ==.
                           1052 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:164: SPI_DAC_Bytes = 0;				// Reset byte TX counter
   012B E4                 1053 	clr	a
   012C F5 0E              1054 	mov	_SPI_DAC_Bytes,a
   012E F5 0F              1055 	mov	(_SPI_DAC_Bytes + 1),a
                    0062   1056 	C$potentiostat_HWtestingMain.c$165$1$1 ==.
                           1057 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:165: NDACCS = 1;						// Deselect the DAC for SPI communication
   0130 D2 94              1058 	setb	_NDACCS
                    0064   1059 	C$potentiostat_HWtestingMain.c$166$1$1 ==.
                           1060 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:166: Writing_to_DAC = 0;
   0132 E4                 1061 	clr	a
   0133 F5 08              1062 	mov	_Writing_to_DAC,a
   0135 F5 09              1063 	mov	(_Writing_to_DAC + 1),a
                    0069   1064 	C$potentiostat_HWtestingMain.c$173$1$1 ==.
                           1065 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:173: NADCCS = 0;						// Select the ADC for SPI communication
   0137 C2 A1              1066 	clr	_NADCCS
                    006B   1067 	C$potentiostat_HWtestingMain.c$174$1$1 ==.
                           1068 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:174: Writing_to_ADC = 1;
   0139 75 0A 01           1069 	mov	_Writing_to_ADC,#0x01
   013C 75 0B 00           1070 	mov	(_Writing_to_ADC + 1),#0x00
                    0071   1071 	C$potentiostat_HWtestingMain.c$175$1$1 ==.
                           1072 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:175: SPI0DAT = 0xA0;					// 0xA0 = 1010 0000
   013F 75 A3 A0           1073 	mov	_SPI0DAT,#0xA0
                    0074   1074 	C$potentiostat_HWtestingMain.c$176$1$1 ==.
                           1075 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:176: while(SPI_ADC_Bytes != 1) {}	// wait for SPI to finish sending byte
   0142                    1076 00110$:
   0142 74 01              1077 	mov	a,#0x01
   0144 B5 10 06           1078 	cjne	a,_SPI_ADC_Bytes,00141$
   0147 E4                 1079 	clr	a
   0148 B5 11 02           1080 	cjne	a,(_SPI_ADC_Bytes + 1),00141$
   014B 80 02              1081 	sjmp	00142$
   014D                    1082 00141$:
   014D 80 F3              1083 	sjmp	00110$
   014F                    1084 00142$:
                    0081   1085 	C$potentiostat_HWtestingMain.c$177$1$1 ==.
                           1086 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:177: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   014F 75 A3 00           1087 	mov	_SPI0DAT,#0x00
                    0084   1088 	C$potentiostat_HWtestingMain.c$178$1$1 ==.
                           1089 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:178: while(SPI_ADC_Bytes != 2) {}	// wait for SPI to finish sending byte
   0152                    1090 00113$:
   0152 74 02              1091 	mov	a,#0x02
   0154 B5 10 06           1092 	cjne	a,_SPI_ADC_Bytes,00143$
   0157 E4                 1093 	clr	a
   0158 B5 11 02           1094 	cjne	a,(_SPI_ADC_Bytes + 1),00143$
   015B 80 02              1095 	sjmp	00144$
   015D                    1096 00143$:
   015D 80 F3              1097 	sjmp	00113$
   015F                    1098 00144$:
                    0091   1099 	C$potentiostat_HWtestingMain.c$179$1$1 ==.
                           1100 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:179: SPI_ADC_Bytes = 0;
   015F E4                 1101 	clr	a
   0160 F5 10              1102 	mov	_SPI_ADC_Bytes,a
   0162 F5 11              1103 	mov	(_SPI_ADC_Bytes + 1),a
                    0096   1104 	C$potentiostat_HWtestingMain.c$180$1$1 ==.
                           1105 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:180: NADCCS = 1;						// Deselect the ADC for SPI communication
   0164 D2 A1              1106 	setb	_NADCCS
                    0098   1107 	C$potentiostat_HWtestingMain.c$181$1$1 ==.
                           1108 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:181: Writing_to_ADC = 0;
   0166 E4                 1109 	clr	a
   0167 F5 0A              1110 	mov	_Writing_to_ADC,a
   0169 F5 0B              1111 	mov	(_Writing_to_ADC + 1),a
                    009D   1112 	C$potentiostat_HWtestingMain.c$183$1$1 ==.
                           1113 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:183: while (1)						// infinte while loop
   016B                    1114 00119$:
                    009D   1115 	C$potentiostat_HWtestingMain.c$185$2$7 ==.
                           1116 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:185: if (Write_to_RAM)
   016B E5 1E              1117 	mov	a,_Write_to_RAM
   016D 45 1F              1118 	orl	a,(_Write_to_RAM + 1)
   016F 60 FA              1119 	jz	00119$
                    00A3   1120 	C$potentiostat_HWtestingMain.c$187$3$8 ==.
                           1121 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:187: RAM_Write();
   0171 12 03 41           1122 	lcall	_RAM_Write
                    00A6   1123 	C$potentiostat_HWtestingMain.c$189$3$8 ==.
                           1124 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:189: EIE1 |= 0x02;					// 0x02 = 0000 0010
   0174 43 E6 02           1125 	orl	_EIE1,#0x02
                    00A9   1126 	C$potentiostat_HWtestingMain.c$193$1$1 ==.
                    00A9   1127 	XG$main$0$0 ==.
   0177 80 F2              1128 	sjmp	00119$
                           1129 ;------------------------------------------------------------
                           1130 ;Allocation info for local variables in function 'SYSCLK_Init'
                           1131 ;------------------------------------------------------------
                           1132 ;delay                     Allocated to registers r2 r3 
                           1133 ;------------------------------------------------------------
                    00AB   1134 	G$SYSCLK_Init$0$0 ==.
                    00AB   1135 	C$potentiostat_HWtestingMain.c$214$1$1 ==.
                           1136 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:214: void SYSCLK_Init (void)
                           1137 ;	-----------------------------------------
                           1138 ;	 function SYSCLK_Init
                           1139 ;	-----------------------------------------
   0179                    1140 _SYSCLK_Init:
                    00AB   1141 	C$potentiostat_HWtestingMain.c$220$1$1 ==.
                           1142 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:220: OSCICN = 0x83;
   0179 75 B2 83           1143 	mov	_OSCICN,#0x83
                    00AE   1144 	C$potentiostat_HWtestingMain.c$223$1$1 ==.
                           1145 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:223: CLKMUL = 0x00;		// Reset clock multiplier
   017C 75 B9 00           1146 	mov	_CLKMUL,#0x00
                    00B1   1147 	C$potentiostat_HWtestingMain.c$224$1$1 ==.
                           1148 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:224: CLKMUL |= 0x80;		// Enable multiplier
   017F 43 B9 80           1149 	orl	_CLKMUL,#0x80
                    00B4   1150 	C$potentiostat_HWtestingMain.c$226$1$1 ==.
                           1151 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:226: while (delay < 72) { delay += 1; }
   0182 7A 00              1152 	mov	r2,#0x00
   0184 7B 00              1153 	mov	r3,#0x00
   0186                    1154 00101$:
   0186 C3                 1155 	clr	c
   0187 EA                 1156 	mov	a,r2
   0188 94 48              1157 	subb	a,#0x48
   018A EB                 1158 	mov	a,r3
   018B 64 80              1159 	xrl	a,#0x80
   018D 94 80              1160 	subb	a,#0x80
   018F 50 07              1161 	jnc	00103$
   0191 0A                 1162 	inc	r2
   0192 BA 00 F1           1163 	cjne	r2,#0x00,00101$
   0195 0B                 1164 	inc	r3
   0196 80 EE              1165 	sjmp	00101$
   0198                    1166 00103$:
                    00CA   1167 	C$potentiostat_HWtestingMain.c$227$1$1 ==.
                           1168 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:227: CLKMUL |= 0xC0;		// Initialize multiplier
   0198 43 B9 C0           1169 	orl	_CLKMUL,#0xC0
                    00CD   1170 	C$potentiostat_HWtestingMain.c$229$1$1 ==.
                           1171 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:229: while ((CLKMUL & MULRDY) != MULRDY) { NOP(); }
   019B                    1172 00104$:
   019B 74 20              1173 	mov	a,#0x20
   019D 55 B9              1174 	anl	a,_CLKMUL
   019F FA                 1175 	mov	r2,a
   01A0 BA 20 02           1176 	cjne	r2,#0x20,00115$
   01A3 80 03              1177 	sjmp	00106$
   01A5                    1178 00115$:
   01A5 00                 1179 	 NOP 
   01A6 80 F3              1180 	sjmp	00104$
   01A8                    1181 00106$:
                    00DA   1182 	C$potentiostat_HWtestingMain.c$230$1$1 ==.
                           1183 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:230: CLKSEL = 0x02;		// USB clock = 4*(Int Osc)
   01A8 75 A9 02           1184 	mov	_CLKSEL,#0x02
                    00DD   1185 	C$potentiostat_HWtestingMain.c$233$1$1 ==.
                           1186 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:233: RSTSRC = 0x04;		// Enable missing clock detector, required for USB
   01AB 75 EF 04           1187 	mov	_RSTSRC,#0x04
                    00E0   1188 	C$potentiostat_HWtestingMain.c$234$1$1 ==.
                    00E0   1189 	XG$SYSCLK_Init$0$0 ==.
   01AE 22                 1190 	ret
                           1191 ;------------------------------------------------------------
                           1192 ;Allocation info for local variables in function 'PORT_Init'
                           1193 ;------------------------------------------------------------
                           1194 ;------------------------------------------------------------
                    00E1   1195 	G$PORT_Init$0$0 ==.
                    00E1   1196 	C$potentiostat_HWtestingMain.c$272$1$1 ==.
                           1197 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:272: void PORT_Init (void)
                           1198 ;	-----------------------------------------
                           1199 ;	 function PORT_Init
                           1200 ;	-----------------------------------------
   01AF                    1201 _PORT_Init:
                    00E1   1202 	C$potentiostat_HWtestingMain.c$275$1$1 ==.
                           1203 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:275: P0MDIN = 0xFF;
   01AF 75 F1 FF           1204 	mov	_P0MDIN,#0xFF
                    00E4   1205 	C$potentiostat_HWtestingMain.c$276$1$1 ==.
                           1206 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:276: P1MDIN = 0xFF;
   01B2 75 F2 FF           1207 	mov	_P1MDIN,#0xFF
                    00E7   1208 	C$potentiostat_HWtestingMain.c$277$1$1 ==.
                           1209 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:277: P2MDIN = 0xFF;
   01B5 75 F3 FF           1210 	mov	_P2MDIN,#0xFF
                    00EA   1211 	C$potentiostat_HWtestingMain.c$278$1$1 ==.
                           1212 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:278: P3MDIN = 0xFF;
   01B8 75 F4 FF           1213 	mov	_P3MDIN,#0xFF
                    00ED   1214 	C$potentiostat_HWtestingMain.c$281$1$1 ==.
                           1215 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:281: P0MDOUT = 0xFF;
   01BB 75 A4 FF           1216 	mov	_P0MDOUT,#0xFF
                    00F0   1217 	C$potentiostat_HWtestingMain.c$282$1$1 ==.
                           1218 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:282: P1MDOUT = 0xFF;
   01BE 75 A5 FF           1219 	mov	_P1MDOUT,#0xFF
                    00F3   1220 	C$potentiostat_HWtestingMain.c$283$1$1 ==.
                           1221 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:283: P2MDOUT = 0xFF;
   01C1 75 A6 FF           1222 	mov	_P2MDOUT,#0xFF
                    00F6   1223 	C$potentiostat_HWtestingMain.c$284$1$1 ==.
                           1224 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:284: P3MDOUT = 0xFF;
   01C4 75 A7 FF           1225 	mov	_P3MDOUT,#0xFF
                    00F9   1226 	C$potentiostat_HWtestingMain.c$287$1$1 ==.
                           1227 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:287: P0SKIP = 0x00;
   01C7 75 D4 00           1228 	mov	_P0SKIP,#0x00
                    00FC   1229 	C$potentiostat_HWtestingMain.c$288$1$1 ==.
                           1230 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:288: P1SKIP = 0x00;
   01CA 75 D5 00           1231 	mov	_P1SKIP,#0x00
                    00FF   1232 	C$potentiostat_HWtestingMain.c$289$1$1 ==.
                           1233 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:289: P2SKIP = 0x00;
   01CD 75 D6 00           1234 	mov	_P2SKIP,#0x00
                    0102   1235 	C$potentiostat_HWtestingMain.c$295$1$1 ==.
                           1236 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:295: XBR0 = 0x02;				// Only SPI selected, automatically assigned:
   01D0 75 E1 02           1237 	mov	_XBR0,#0x02
                    0105   1238 	C$potentiostat_HWtestingMain.c$299$1$1 ==.
                           1239 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:299: XBR1 = 0x40;				// Enable crossbar and weak pull-ups
   01D3 75 E2 40           1240 	mov	_XBR1,#0x40
                    0108   1241 	C$potentiostat_HWtestingMain.c$314$1$1 ==.
                           1242 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:314: NADCCS = 1;
   01D6 D2 A1              1243 	setb	_NADCCS
                    010A   1244 	C$potentiostat_HWtestingMain.c$315$1$1 ==.
                           1245 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:315: NDACCS = 1;
   01D8 D2 94              1246 	setb	_NDACCS
                    010C   1247 	C$potentiostat_HWtestingMain.c$316$1$1 ==.
                           1248 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:316: NRAMCS = 1;
   01DA D2 A6              1249 	setb	_NRAMCS
                    010E   1250 	C$potentiostat_HWtestingMain.c$317$1$1 ==.
                           1251 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:317: NRAMHOLD = 1;
   01DC D2 A7              1252 	setb	_NRAMHOLD
                    0110   1253 	C$potentiostat_HWtestingMain.c$318$1$1 ==.
                           1254 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:318: NotDriverEN = 1;			// Enable/disable (0/1) stepper motor driver
   01DE D2 85              1255 	setb	_NotDriverEN
                    0112   1256 	C$potentiostat_HWtestingMain.c$320$1$1 ==.
                           1257 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:320: Motor1Dir = 0;
   01E0 C2 86              1258 	clr	_Motor1Dir
                    0114   1259 	C$potentiostat_HWtestingMain.c$321$1$1 ==.
                           1260 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:321: Motor2Dir = 0;
   01E2 C2 83              1261 	clr	_Motor2Dir
                    0116   1262 	C$potentiostat_HWtestingMain.c$322$1$1 ==.
                           1263 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:322: Motor1Step = 0;
   01E4 C2 87              1264 	clr	_Motor1Step
                    0118   1265 	C$potentiostat_HWtestingMain.c$323$1$1 ==.
                           1266 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:323: Motor2Step = 0;
   01E6 C2 84              1267 	clr	_Motor2Step
                    011A   1268 	C$potentiostat_HWtestingMain.c$324$1$1 ==.
                           1269 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:324: LASER = 0;					// Disable laswer power
   01E8 C2 92              1270 	clr	_LASER
                    011C   1271 	C$potentiostat_HWtestingMain.c$325$1$1 ==.
                           1272 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:325: OUTPUTEN = 0;				// Disable the output until we're ready
   01EA C2 A3              1273 	clr	_OUTPUTEN
                    011E   1274 	C$potentiostat_HWtestingMain.c$326$1$1 ==.
                           1275 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:326: POS = 1;					// Positive voltage and current
   01EC D2 A0              1276 	setb	_POS
                    0120   1277 	C$potentiostat_HWtestingMain.c$327$1$1 ==.
                           1278 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:327: CAL = 0;					// Not in calibration state
   01EE C2 97              1279 	clr	_CAL
                    0122   1280 	C$potentiostat_HWtestingMain.c$329$1$1 ==.
                    0122   1281 	XG$PORT_Init$0$0 ==.
   01F0 22                 1282 	ret
                           1283 ;------------------------------------------------------------
                           1284 ;Allocation info for local variables in function 'Timer1_Init'
                           1285 ;------------------------------------------------------------
                           1286 ;------------------------------------------------------------
                    0123   1287 	G$Timer1_Init$0$0 ==.
                    0123   1288 	C$potentiostat_HWtestingMain.c$342$1$1 ==.
                           1289 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:342: void Timer1_Init (void)
                           1290 ;	-----------------------------------------
                           1291 ;	 function Timer1_Init
                           1292 ;	-----------------------------------------
   01F1                    1293 _Timer1_Init:
                    0123   1294 	C$potentiostat_HWtestingMain.c$345$1$1 ==.
                           1295 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:345: TCON &= 0xBF;					// 0xBF = 1011 1111, Stop Timer1
   01F1 53 88 BF           1296 	anl	_TCON,#0xBF
                    0126   1297 	C$potentiostat_HWtestingMain.c$347$1$1 ==.
                           1298 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:347: CKCON &= 0xF6;					// Set Timer 1 to use the prescaled
   01F4 53 8E F6           1299 	anl	_CKCON,#0xF6
                    0129   1300 	C$potentiostat_HWtestingMain.c$348$1$1 ==.
                           1301 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:348: CKCON |= 0x02;					// clock and set prescale to 1/48.
   01F7 43 8E 02           1302 	orl	_CKCON,#0x02
                    012C   1303 	C$potentiostat_HWtestingMain.c$357$1$1 ==.
                           1304 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:357: TL1 = 0x06;						// load both so first interrupt is
   01FA 75 8B 06           1305 	mov	_TL1,#0x06
                    012F   1306 	C$potentiostat_HWtestingMain.c$358$1$1 ==.
                           1307 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:358: TH1 = 0x06;						// after 0.5 ms.
   01FD 75 8D 06           1308 	mov	_TH1,#0x06
                    0132   1309 	C$potentiostat_HWtestingMain.c$361$1$1 ==.
                           1310 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:361: TMOD &= 0x2F;					// 0x2F = 0010 1111
   0200 53 89 2F           1311 	anl	_TMOD,#0x2F
                    0135   1312 	C$potentiostat_HWtestingMain.c$362$1$1 ==.
                           1313 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:362: TMOD |= 0x20;					// 0x20 = 0010 0000
   0203 43 89 20           1314 	orl	_TMOD,#0x20
                    0138   1315 	C$potentiostat_HWtestingMain.c$365$1$1 ==.
                           1316 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:365: TCON &= 0x7F;					// 0x7F = 0111 1111, Clear interrupt flag
   0206 53 88 7F           1317 	anl	_TCON,#0x7F
                    013B   1318 	C$potentiostat_HWtestingMain.c$366$1$1 ==.
                           1319 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:366: TCON |= 0x40;					// 0x40 = 0100 0000, Start Timer1
   0209 43 88 40           1320 	orl	_TCON,#0x40
                    013E   1321 	C$potentiostat_HWtestingMain.c$371$1$1 ==.
                           1322 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:371: PT1 = 1;
   020C D2 BB              1323 	setb	_PT1
                    0140   1324 	C$potentiostat_HWtestingMain.c$376$1$1 ==.
                           1325 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:376: CPT1CN = 0x80;	// 0x80 = 1000 0000
   020E 75 9A 80           1326 	mov	_CPT1CN,#0x80
                    0143   1327 	C$potentiostat_HWtestingMain.c$381$1$1 ==.
                           1328 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:381: EIE1 |= 0x40;	// 0x40 = 0100 0000
   0211 43 E6 40           1329 	orl	_EIE1,#0x40
                    0146   1330 	C$potentiostat_HWtestingMain.c$385$1$1 ==.
                           1331 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:385: ET1 = 1;
   0214 D2 AB              1332 	setb	_ET1
                    0148   1333 	C$potentiostat_HWtestingMain.c$386$1$1 ==.
                    0148   1334 	XG$Timer1_Init$0$0 ==.
   0216 22                 1335 	ret
                           1336 ;------------------------------------------------------------
                           1337 ;Allocation info for local variables in function 'Timer2_Init'
                           1338 ;------------------------------------------------------------
                           1339 ;counts                    Allocated to registers 
                           1340 ;------------------------------------------------------------
                    0149   1341 	G$Timer2_Init$0$0 ==.
                    0149   1342 	C$potentiostat_HWtestingMain.c$399$1$1 ==.
                           1343 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:399: void Timer2_Init (int counts)
                           1344 ;	-----------------------------------------
                           1345 ;	 function Timer2_Init
                           1346 ;	-----------------------------------------
   0217                    1347 _Timer2_Init:
                    0149   1348 	C$potentiostat_HWtestingMain.c$401$1$1 ==.
                           1349 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:401: TMR2CN = 0x00;						// Stop Timer2; Clear TF2;
   0217 75 C8 00           1350 	mov	_TMR2CN,#0x00
                    014C   1351 	C$potentiostat_HWtestingMain.c$403$1$1 ==.
                           1352 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:403: CKCON &= ~0x30;						// Timer2 clocked based on T2XCLK;
   021A 53 8E CF           1353 	anl	_CKCON,#0xCF
                    014F   1354 	C$potentiostat_HWtestingMain.c$406$1$1 ==.
                           1355 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:406: TMR2RL = 0x0000;						// Init reload values
   021D E4                 1356 	clr	a
   021E F5 CA              1357 	mov	_TMR2RL,a
   0220 F5 CB              1358 	mov	(_TMR2RL >> 8),a
                    0154   1359 	C$potentiostat_HWtestingMain.c$407$1$1 ==.
                           1360 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:407: TMR2 = 0xffff;						// Set to reload immediately
   0222 75 CC FF           1361 	mov	_TMR2,#0xFF
   0225 75 CD FF           1362 	mov	(_TMR2 >> 8),#0xFF
                    015A   1363 	C$potentiostat_HWtestingMain.c$408$1$1 ==.
                           1364 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:408: ET2 = 1;								// Enable Timer2 interrupts
   0228 D2 AD              1365 	setb	_ET2
                    015C   1366 	C$potentiostat_HWtestingMain.c$409$1$1 ==.
                           1367 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:409: TR2 = 1;								// Start Timer2
   022A D2 CA              1368 	setb	_TR2
                    015E   1369 	C$potentiostat_HWtestingMain.c$410$1$1 ==.
                    015E   1370 	XG$Timer2_Init$0$0 ==.
   022C 22                 1371 	ret
                           1372 ;------------------------------------------------------------
                           1373 ;Allocation info for local variables in function 'SPI_Init'
                           1374 ;------------------------------------------------------------
                           1375 ;------------------------------------------------------------
                    015F   1376 	G$SPI_Init$0$0 ==.
                    015F   1377 	C$potentiostat_HWtestingMain.c$423$1$1 ==.
                           1378 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:423: void SPI_Init (void)
                           1379 ;	-----------------------------------------
                           1380 ;	 function SPI_Init
                           1381 ;	-----------------------------------------
   022D                    1382 _SPI_Init:
                    015F   1383 	C$potentiostat_HWtestingMain.c$426$1$1 ==.
                           1384 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:426: NDACCS = 1;
   022D D2 94              1385 	setb	_NDACCS
                    0161   1386 	C$potentiostat_HWtestingMain.c$427$1$1 ==.
                           1387 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:427: NADCCS = 1;
   022F D2 A1              1388 	setb	_NADCCS
                    0163   1389 	C$potentiostat_HWtestingMain.c$428$1$1 ==.
                           1390 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:428: NRAMCS = 1;
   0231 D2 A6              1391 	setb	_NRAMCS
                    0165   1392 	C$potentiostat_HWtestingMain.c$439$1$1 ==.
                           1393 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:439: SPI0CFG = 0x50;				// 0x60 = 0101 0000
   0233 75 A1 50           1394 	mov	_SPI0CFG,#0x50
                    0168   1395 	C$potentiostat_HWtestingMain.c$450$1$1 ==.
                           1396 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:450: SPI0CN = 0x01;				// 0x01 = 0000 0001
   0236 75 F8 01           1397 	mov	_SPI0CN,#0x01
                    016B   1398 	C$potentiostat_HWtestingMain.c$462$1$1 ==.
                           1399 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:462: SPI0CKR = 0x05;				// 0x00 = 0000 0101
   0239 75 A2 05           1400 	mov	_SPI0CKR,#0x05
                    016E   1401 	C$potentiostat_HWtestingMain.c$465$1$1 ==.
                           1402 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:465: ESPI0 = 1;
   023C D2 AE              1403 	setb	_ESPI0
                    0170   1404 	C$potentiostat_HWtestingMain.c$466$1$1 ==.
                    0170   1405 	XG$SPI_Init$0$0 ==.
   023E 22                 1406 	ret
                           1407 ;------------------------------------------------------------
                           1408 ;Allocation info for local variables in function 'DAC_Init'
                           1409 ;------------------------------------------------------------
                           1410 ;------------------------------------------------------------
                    0171   1411 	G$DAC_Init$0$0 ==.
                    0171   1412 	C$potentiostat_HWtestingMain.c$479$1$1 ==.
                           1413 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:479: void DAC_Init (void)
                           1414 ;	-----------------------------------------
                           1415 ;	 function DAC_Init
                           1416 ;	-----------------------------------------
   023F                    1417 _DAC_Init:
                    0171   1418 	C$potentiostat_HWtestingMain.c$481$1$1 ==.
                           1419 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:481: Writing_to_DAC = 1;
   023F 75 08 01           1420 	mov	_Writing_to_DAC,#0x01
   0242 75 09 00           1421 	mov	(_Writing_to_DAC + 1),#0x00
                    0177   1422 	C$potentiostat_HWtestingMain.c$494$1$1 ==.
                           1423 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:494: NDACCS = 0;						// Select the DAC for SPI communication
   0245 C2 94              1424 	clr	_NDACCS
                    0179   1425 	C$potentiostat_HWtestingMain.c$495$1$1 ==.
                           1426 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:495: SPI0DAT = 0x08;					// 0x08 = 0000 1000
   0247 75 A3 08           1427 	mov	_SPI0DAT,#0x08
                    017C   1428 	C$potentiostat_HWtestingMain.c$496$1$1 ==.
                           1429 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:496: while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
   024A                    1430 00101$:
   024A 74 01              1431 	mov	a,#0x01
   024C B5 0E 06           1432 	cjne	a,_SPI_DAC_Bytes,00148$
   024F E4                 1433 	clr	a
   0250 B5 0F 02           1434 	cjne	a,(_SPI_DAC_Bytes + 1),00148$
   0253 80 02              1435 	sjmp	00149$
   0255                    1436 00148$:
   0255 80 F3              1437 	sjmp	00101$
   0257                    1438 00149$:
                    0189   1439 	C$potentiostat_HWtestingMain.c$497$1$1 ==.
                           1440 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:497: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   0257 75 A3 00           1441 	mov	_SPI0DAT,#0x00
                    018C   1442 	C$potentiostat_HWtestingMain.c$498$1$1 ==.
                           1443 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:498: while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
   025A                    1444 00104$:
   025A 74 02              1445 	mov	a,#0x02
   025C B5 0E 06           1446 	cjne	a,_SPI_DAC_Bytes,00150$
   025F E4                 1447 	clr	a
   0260 B5 0F 02           1448 	cjne	a,(_SPI_DAC_Bytes + 1),00150$
   0263 80 02              1449 	sjmp	00151$
   0265                    1450 00150$:
   0265 80 F3              1451 	sjmp	00104$
   0267                    1452 00151$:
                    0199   1453 	C$potentiostat_HWtestingMain.c$499$1$1 ==.
                           1454 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:499: SPI0DAT = 0x04;					// 0x04 = 0000 0100
   0267 75 A3 04           1455 	mov	_SPI0DAT,#0x04
                    019C   1456 	C$potentiostat_HWtestingMain.c$500$1$1 ==.
                           1457 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:500: while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
   026A                    1458 00107$:
   026A 74 03              1459 	mov	a,#0x03
   026C B5 0E 06           1460 	cjne	a,_SPI_DAC_Bytes,00152$
   026F E4                 1461 	clr	a
   0270 B5 0F 02           1462 	cjne	a,(_SPI_DAC_Bytes + 1),00152$
   0273 80 02              1463 	sjmp	00153$
   0275                    1464 00152$:
   0275 80 F3              1465 	sjmp	00107$
   0277                    1466 00153$:
                    01A9   1467 	C$potentiostat_HWtestingMain.c$501$1$1 ==.
                           1468 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:501: SPI_DAC_Bytes -= 3;				// Reset byte TX counter
   0277 E5 0E              1469 	mov	a,_SPI_DAC_Bytes
   0279 24 FD              1470 	add	a,#0xfd
   027B F5 0E              1471 	mov	_SPI_DAC_Bytes,a
   027D E5 0F              1472 	mov	a,(_SPI_DAC_Bytes + 1)
   027F 34 FF              1473 	addc	a,#0xff
   0281 F5 0F              1474 	mov	(_SPI_DAC_Bytes + 1),a
                    01B5   1475 	C$potentiostat_HWtestingMain.c$502$1$1 ==.
                           1476 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:502: NDACCS = 1;						// Deselect the DAC for SPI communication
   0283 D2 94              1477 	setb	_NDACCS
                    01B7   1478 	C$potentiostat_HWtestingMain.c$518$1$1 ==.
                           1479 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:518: NDACCS = 0;						// Select the DAC for SPI communication
   0285 C2 94              1480 	clr	_NDACCS
                    01B9   1481 	C$potentiostat_HWtestingMain.c$519$1$1 ==.
                           1482 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:519: SPI0DAT = 0x19;					// 0x19 = 0001 1001
   0287 75 A3 19           1483 	mov	_SPI0DAT,#0x19
                    01BC   1484 	C$potentiostat_HWtestingMain.c$520$1$1 ==.
                           1485 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:520: while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
   028A                    1486 00110$:
   028A 74 01              1487 	mov	a,#0x01
   028C B5 0E 06           1488 	cjne	a,_SPI_DAC_Bytes,00154$
   028F E4                 1489 	clr	a
   0290 B5 0F 02           1490 	cjne	a,(_SPI_DAC_Bytes + 1),00154$
   0293 80 02              1491 	sjmp	00155$
   0295                    1492 00154$:
   0295 80 F3              1493 	sjmp	00110$
   0297                    1494 00155$:
                    01C9   1495 	C$potentiostat_HWtestingMain.c$521$1$1 ==.
                           1496 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:521: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   0297 75 A3 00           1497 	mov	_SPI0DAT,#0x00
                    01CC   1498 	C$potentiostat_HWtestingMain.c$522$1$1 ==.
                           1499 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:522: while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
   029A                    1500 00113$:
   029A 74 02              1501 	mov	a,#0x02
   029C B5 0E 06           1502 	cjne	a,_SPI_DAC_Bytes,00156$
   029F E4                 1503 	clr	a
   02A0 B5 0F 02           1504 	cjne	a,(_SPI_DAC_Bytes + 1),00156$
   02A3 80 02              1505 	sjmp	00157$
   02A5                    1506 00156$:
   02A5 80 F3              1507 	sjmp	00113$
   02A7                    1508 00157$:
                    01D9   1509 	C$potentiostat_HWtestingMain.c$523$1$1 ==.
                           1510 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:523: SPI0DAT = 0x0E;					// 0x0E = 0000 1110
   02A7 75 A3 0E           1511 	mov	_SPI0DAT,#0x0E
                    01DC   1512 	C$potentiostat_HWtestingMain.c$524$1$1 ==.
                           1513 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:524: while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
   02AA                    1514 00116$:
   02AA 74 03              1515 	mov	a,#0x03
   02AC B5 0E 06           1516 	cjne	a,_SPI_DAC_Bytes,00158$
   02AF E4                 1517 	clr	a
   02B0 B5 0F 02           1518 	cjne	a,(_SPI_DAC_Bytes + 1),00158$
   02B3 80 02              1519 	sjmp	00159$
   02B5                    1520 00158$:
   02B5 80 F3              1521 	sjmp	00116$
   02B7                    1522 00159$:
                    01E9   1523 	C$potentiostat_HWtestingMain.c$525$1$1 ==.
                           1524 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:525: SPI_DAC_Bytes -= 3;				// Reset byte TX counter
   02B7 E5 0E              1525 	mov	a,_SPI_DAC_Bytes
   02B9 24 FD              1526 	add	a,#0xfd
   02BB F5 0E              1527 	mov	_SPI_DAC_Bytes,a
   02BD E5 0F              1528 	mov	a,(_SPI_DAC_Bytes + 1)
   02BF 34 FF              1529 	addc	a,#0xff
   02C1 F5 0F              1530 	mov	(_SPI_DAC_Bytes + 1),a
                    01F5   1531 	C$potentiostat_HWtestingMain.c$526$1$1 ==.
                           1532 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:526: NDACCS = 1;						// Deselect the DAC for SPI communication
   02C3 D2 94              1533 	setb	_NDACCS
                    01F7   1534 	C$potentiostat_HWtestingMain.c$545$1$1 ==.
                           1535 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:545: NDACCS = 0;						// Select the DAC for SPI communication
   02C5 C2 94              1536 	clr	_NDACCS
                    01F9   1537 	C$potentiostat_HWtestingMain.c$546$1$1 ==.
                           1538 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:546: SPI0DAT = 0x10;					// 0x10 = 0001 0000
   02C7 75 A3 10           1539 	mov	_SPI0DAT,#0x10
                    01FC   1540 	C$potentiostat_HWtestingMain.c$547$1$1 ==.
                           1541 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:547: while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
   02CA                    1542 00119$:
   02CA 74 01              1543 	mov	a,#0x01
   02CC B5 0E 06           1544 	cjne	a,_SPI_DAC_Bytes,00160$
   02CF E4                 1545 	clr	a
   02D0 B5 0F 02           1546 	cjne	a,(_SPI_DAC_Bytes + 1),00160$
   02D3 80 02              1547 	sjmp	00161$
   02D5                    1548 00160$:
   02D5 80 F3              1549 	sjmp	00119$
   02D7                    1550 00161$:
                    0209   1551 	C$potentiostat_HWtestingMain.c$548$1$1 ==.
                           1552 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:548: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   02D7 75 A3 00           1553 	mov	_SPI0DAT,#0x00
                    020C   1554 	C$potentiostat_HWtestingMain.c$549$1$1 ==.
                           1555 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:549: while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
   02DA                    1556 00122$:
   02DA 74 02              1557 	mov	a,#0x02
   02DC B5 0E 06           1558 	cjne	a,_SPI_DAC_Bytes,00162$
   02DF E4                 1559 	clr	a
   02E0 B5 0F 02           1560 	cjne	a,(_SPI_DAC_Bytes + 1),00162$
   02E3 80 02              1561 	sjmp	00163$
   02E5                    1562 00162$:
   02E5 80 F3              1563 	sjmp	00122$
   02E7                    1564 00163$:
                    0219   1565 	C$potentiostat_HWtestingMain.c$550$1$1 ==.
                           1566 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:550: SPI0DAT = 0x01;					// 0x0F = 0000 0001
   02E7 75 A3 01           1567 	mov	_SPI0DAT,#0x01
                    021C   1568 	C$potentiostat_HWtestingMain.c$551$1$1 ==.
                           1569 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:551: while(SPI_DAC_Bytes != 3) {}	// wait for SPI to finish sending byte
   02EA                    1570 00125$:
   02EA 74 03              1571 	mov	a,#0x03
   02EC B5 0E 06           1572 	cjne	a,_SPI_DAC_Bytes,00164$
   02EF E4                 1573 	clr	a
   02F0 B5 0F 02           1574 	cjne	a,(_SPI_DAC_Bytes + 1),00164$
   02F3 80 02              1575 	sjmp	00165$
   02F5                    1576 00164$:
   02F5 80 F3              1577 	sjmp	00125$
   02F7                    1578 00165$:
                    0229   1579 	C$potentiostat_HWtestingMain.c$552$1$1 ==.
                           1580 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:552: SPI_DAC_Bytes -= 3;				// Reset byte TX counter
   02F7 E5 0E              1581 	mov	a,_SPI_DAC_Bytes
   02F9 24 FD              1582 	add	a,#0xfd
   02FB F5 0E              1583 	mov	_SPI_DAC_Bytes,a
   02FD E5 0F              1584 	mov	a,(_SPI_DAC_Bytes + 1)
   02FF 34 FF              1585 	addc	a,#0xff
   0301 F5 0F              1586 	mov	(_SPI_DAC_Bytes + 1),a
                    0235   1587 	C$potentiostat_HWtestingMain.c$553$1$1 ==.
                           1588 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:553: NDACCS = 1;						// Deselect the DAC for SPI communication
   0303 D2 94              1589 	setb	_NDACCS
                    0237   1590 	C$potentiostat_HWtestingMain.c$555$1$1 ==.
                           1591 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:555: Writing_to_DAC = 0;
   0305 E4                 1592 	clr	a
   0306 F5 08              1593 	mov	_Writing_to_DAC,a
   0308 F5 09              1594 	mov	(_Writing_to_DAC + 1),a
                    023C   1595 	C$potentiostat_HWtestingMain.c$557$1$1 ==.
                    023C   1596 	XG$DAC_Init$0$0 ==.
   030A 22                 1597 	ret
                           1598 ;------------------------------------------------------------
                           1599 ;Allocation info for local variables in function 'ADC_Init'
                           1600 ;------------------------------------------------------------
                           1601 ;------------------------------------------------------------
                    023D   1602 	G$ADC_Init$0$0 ==.
                    023D   1603 	C$potentiostat_HWtestingMain.c$569$1$1 ==.
                           1604 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:569: void ADC_Init (void)
                           1605 ;	-----------------------------------------
                           1606 ;	 function ADC_Init
                           1607 ;	-----------------------------------------
   030B                    1608 _ADC_Init:
                    023D   1609 	C$potentiostat_HWtestingMain.c$571$1$1 ==.
                           1610 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:571: Writing_to_ADC = 1;
   030B 75 0A 01           1611 	mov	_Writing_to_ADC,#0x01
   030E 75 0B 00           1612 	mov	(_Writing_to_ADC + 1),#0x00
                    0243   1613 	C$potentiostat_HWtestingMain.c$586$1$1 ==.
                           1614 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:586: SPI0CFG = 0x40;				// 0x60 = 0100 0000
   0311 75 A1 40           1615 	mov	_SPI0CFG,#0x40
                    0246   1616 	C$potentiostat_HWtestingMain.c$598$1$1 ==.
                           1617 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:598: SPI0CKR = 0x05;				// 0x00 = 0000 0101
   0314 75 A2 05           1618 	mov	_SPI0CKR,#0x05
                    0249   1619 	C$potentiostat_HWtestingMain.c$611$1$1 ==.
                           1620 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:611: NADCCS = 0;						// Select the DAC for SPI communication
   0317 C2 A1              1621 	clr	_NADCCS
                    024B   1622 	C$potentiostat_HWtestingMain.c$612$1$1 ==.
                           1623 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:612: SPI0DAT = 0xA0;					// 0xA0 = 1010 0000
   0319 75 A3 A0           1624 	mov	_SPI0DAT,#0xA0
                    024E   1625 	C$potentiostat_HWtestingMain.c$613$1$1 ==.
                           1626 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:613: while(SPI_DAC_Bytes != 1) {}	// wait for SPI to finish sending byte
   031C                    1627 00101$:
   031C 74 01              1628 	mov	a,#0x01
   031E B5 0E 06           1629 	cjne	a,_SPI_DAC_Bytes,00113$
   0321 E4                 1630 	clr	a
   0322 B5 0F 02           1631 	cjne	a,(_SPI_DAC_Bytes + 1),00113$
   0325 80 02              1632 	sjmp	00114$
   0327                    1633 00113$:
   0327 80 F3              1634 	sjmp	00101$
   0329                    1635 00114$:
                    025B   1636 	C$potentiostat_HWtestingMain.c$614$1$1 ==.
                           1637 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:614: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   0329 75 A3 00           1638 	mov	_SPI0DAT,#0x00
                    025E   1639 	C$potentiostat_HWtestingMain.c$615$1$1 ==.
                           1640 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:615: while(SPI_DAC_Bytes != 2) {}	// wait for SPI to finish sending byte
   032C                    1641 00104$:
   032C 74 02              1642 	mov	a,#0x02
   032E B5 0E 06           1643 	cjne	a,_SPI_DAC_Bytes,00115$
   0331 E4                 1644 	clr	a
   0332 B5 0F 02           1645 	cjne	a,(_SPI_DAC_Bytes + 1),00115$
   0335 80 02              1646 	sjmp	00116$
   0337                    1647 00115$:
   0337 80 F3              1648 	sjmp	00104$
   0339                    1649 00116$:
                    026B   1650 	C$potentiostat_HWtestingMain.c$616$1$1 ==.
                           1651 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:616: NADCCS = 1;						// Deselect the DAC for SPI communication
   0339 D2 A1              1652 	setb	_NADCCS
                    026D   1653 	C$potentiostat_HWtestingMain.c$618$1$1 ==.
                           1654 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:618: Writing_to_ADC = 0;
   033B E4                 1655 	clr	a
   033C F5 0A              1656 	mov	_Writing_to_ADC,a
   033E F5 0B              1657 	mov	(_Writing_to_ADC + 1),a
                    0272   1658 	C$potentiostat_HWtestingMain.c$619$1$1 ==.
                    0272   1659 	XG$ADC_Init$0$0 ==.
   0340 22                 1660 	ret
                           1661 ;------------------------------------------------------------
                           1662 ;Allocation info for local variables in function 'RAM_Write'
                           1663 ;------------------------------------------------------------
                           1664 ;------------------------------------------------------------
                    0273   1665 	G$RAM_Write$0$0 ==.
                    0273   1666 	C$potentiostat_HWtestingMain.c$621$1$1 ==.
                           1667 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:621: void RAM_Write ()
                           1668 ;	-----------------------------------------
                           1669 ;	 function RAM_Write
                           1670 ;	-----------------------------------------
   0341                    1671 _RAM_Write:
                    0273   1672 	C$potentiostat_HWtestingMain.c$625$1$1 ==.
                           1673 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:625: SPI0CFG = 0x40;				// 0x60 = 0100 0000
   0341 75 A1 40           1674 	mov	_SPI0CFG,#0x40
                    0276   1675 	C$potentiostat_HWtestingMain.c$626$1$1 ==.
                           1676 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:626: SPI0CKR = 0x00;				// 0x00 = 0000 0000
   0344 75 A2 00           1677 	mov	_SPI0CKR,#0x00
                    0279   1678 	C$potentiostat_HWtestingMain.c$629$1$1 ==.
                           1679 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:629: Writing_to_RAM = 1;
   0347 75 0C 01           1680 	mov	_Writing_to_RAM,#0x01
   034A 75 0D 00           1681 	mov	(_Writing_to_RAM + 1),#0x00
                    027F   1682 	C$potentiostat_HWtestingMain.c$639$1$1 ==.
                           1683 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:639: NRAMCS = 0;
   034D C2 A6              1684 	clr	_NRAMCS
                    0281   1685 	C$potentiostat_HWtestingMain.c$640$1$1 ==.
                           1686 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:640: SPI_RAM_Bytes = 0;
   034F E4                 1687 	clr	a
   0350 F5 12              1688 	mov	_SPI_RAM_Bytes,a
   0352 F5 13              1689 	mov	(_SPI_RAM_Bytes + 1),a
                    0286   1690 	C$potentiostat_HWtestingMain.c$642$1$1 ==.
                           1691 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:642: SPI0DAT = 0x02;					// 0x02 = 0000 0010
   0354 75 A3 02           1692 	mov	_SPI0DAT,#0x02
                    0289   1693 	C$potentiostat_HWtestingMain.c$643$1$1 ==.
                           1694 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:643: while(SPI_RAM_Bytes != 1) {}	// wait for SPI to finish sending byte
   0357                    1695 00101$:
                    0289   1696 	C$potentiostat_HWtestingMain.c$704$1$1 ==.
                           1697 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:704: Writing_to_RAM = 0;
                    0289   1698 	C$potentiostat_HWtestingMain.c$705$1$1 ==.
                    0289   1699 	XG$RAM_Write$0$0 ==.
   0357 80 FE              1700 	sjmp	00101$
                           1701 ;------------------------------------------------------------
                           1702 ;Allocation info for local variables in function 'SPI_ISR'
                           1703 ;------------------------------------------------------------
                           1704 ;RXbyte                    Allocated to registers r2 r3 
                           1705 ;------------------------------------------------------------
                    028B   1706 	G$SPI_ISR$0$0 ==.
                    028B   1707 	C$potentiostat_HWtestingMain.c$718$1$1 ==.
                           1708 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:718: INTERRUPT(SPI_ISR, INTERRUPT_SPI0)
                           1709 ;	-----------------------------------------
                           1710 ;	 function SPI_ISR
                           1711 ;	-----------------------------------------
   0359                    1712 _SPI_ISR:
   0359 C0 E0              1713 	push	acc
   035B C0 F0              1714 	push	b
   035D C0 02              1715 	push	ar2
   035F C0 03              1716 	push	ar3
   0361 C0 D0              1717 	push	psw
   0363 75 D0 00           1718 	mov	psw,#0x00
                    0298   1719 	C$potentiostat_HWtestingMain.c$728$1$1 ==.
                           1720 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:728: if ((SPI0CN & 0x80) == 0x80)		// TX complete, byte ready to read
   0366 74 80              1721 	mov	a,#0x80
   0368 55 F8              1722 	anl	a,_SPI0CN
   036A FA                 1723 	mov	r2,a
   036B BA 80 02           1724 	cjne	r2,#0x80,00131$
   036E 80 03              1725 	sjmp	00132$
   0370                    1726 00131$:
   0370 02 03 E3           1727 	ljmp	00114$
   0373                    1728 00132$:
                    02A5   1729 	C$potentiostat_HWtestingMain.c$730$2$2 ==.
                           1730 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:730: SPIF = 0;			// clear interrupt flag
   0373 C2 FF              1731 	clr	_SPIF
                    02A7   1732 	C$potentiostat_HWtestingMain.c$731$2$2 ==.
                           1733 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:731: RXbyte = SPI0DAT;	// This could be a byte from the DAC, ADC, or RAM.
   0375 AA A3              1734 	mov	r2,_SPI0DAT
   0377 7B 00              1735 	mov	r3,#0x00
                    02AB   1736 	C$potentiostat_HWtestingMain.c$732$2$2 ==.
                           1737 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:732: if (Writing_to_ADC > 0)			// ADC
   0379 C3                 1738 	clr	c
   037A E4                 1739 	clr	a
   037B 95 0A              1740 	subb	a,_Writing_to_ADC
   037D 74 80              1741 	mov	a,#(0x00 ^ 0x80)
   037F 85 0B F0           1742 	mov	b,(_Writing_to_ADC + 1)
   0382 63 F0 80           1743 	xrl	b,#0x80
   0385 95 F0              1744 	subb	a,b
   0387 50 24              1745 	jnc	00111$
                    02BB   1746 	C$potentiostat_HWtestingMain.c$734$3$3 ==.
                           1747 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:734: SPI_ADC_Bytes++;			// Do not zero in this ISR
   0389 05 10              1748 	inc	_SPI_ADC_Bytes
   038B E4                 1749 	clr	a
   038C B5 10 02           1750 	cjne	a,_SPI_ADC_Bytes,00134$
   038F 05 11              1751 	inc	(_SPI_ADC_Bytes + 1)
   0391                    1752 00134$:
                    02C3   1753 	C$potentiostat_HWtestingMain.c$735$3$3 ==.
                           1754 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:735: if (SPI_ADC_Bytes == 0)
   0391 E5 10              1755 	mov	a,_SPI_ADC_Bytes
   0393 45 11              1756 	orl	a,(_SPI_ADC_Bytes + 1)
   0395 70 06              1757 	jnz	00102$
                    02C9   1758 	C$potentiostat_HWtestingMain.c$737$4$4 ==.
                           1759 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:737: latest_ADC_HighByte = RXbyte;
   0397 8A 1A              1760 	mov	_latest_ADC_HighByte,r2
   0399 8B 1B              1761 	mov	(_latest_ADC_HighByte + 1),r3
   039B 80 46              1762 	sjmp	00114$
   039D                    1763 00102$:
                    02CF   1764 	C$potentiostat_HWtestingMain.c$741$4$5 ==.
                           1765 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:741: latest_ADC_LowByte = RXbyte;
   039D 8A 1C              1766 	mov	_latest_ADC_LowByte,r2
   039F 8B 1D              1767 	mov	(_latest_ADC_LowByte + 1),r3
                    02D3   1768 	C$potentiostat_HWtestingMain.c$746$4$5 ==.
                           1769 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:746: Writing_to_ADC = 1;		// Change back to writing to ADC
   03A1 75 0A 01           1770 	mov	_Writing_to_ADC,#0x01
                    02D6   1771 	C$potentiostat_HWtestingMain.c$747$4$5 ==.
                           1772 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:747: Writing_to_RAM = 0;
   03A4 E4                 1773 	clr	a
   03A5 F5 0B              1774 	mov	(_Writing_to_ADC + 1),a
   03A7 F5 0C              1775 	mov	_Writing_to_RAM,a
   03A9 F5 0D              1776 	mov	(_Writing_to_RAM + 1),a
   03AB 80 36              1777 	sjmp	00114$
   03AD                    1778 00111$:
                    02DF   1779 	C$potentiostat_HWtestingMain.c$750$2$2 ==.
                           1780 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:750: else if (Writing_to_DAC > 0)	// DAC
   03AD C3                 1781 	clr	c
   03AE E4                 1782 	clr	a
   03AF 95 08              1783 	subb	a,_Writing_to_DAC
   03B1 74 80              1784 	mov	a,#(0x00 ^ 0x80)
   03B3 85 09 F0           1785 	mov	b,(_Writing_to_DAC + 1)
   03B6 63 F0 80           1786 	xrl	b,#0x80
   03B9 95 F0              1787 	subb	a,b
   03BB 50 0A              1788 	jnc	00108$
                    02EF   1789 	C$potentiostat_HWtestingMain.c$752$3$6 ==.
                           1790 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:752: SPI_DAC_Bytes++;			// Do not zero in this ISR
   03BD 05 0E              1791 	inc	_SPI_DAC_Bytes
   03BF E4                 1792 	clr	a
   03C0 B5 0E 20           1793 	cjne	a,_SPI_DAC_Bytes,00114$
   03C3 05 0F              1794 	inc	(_SPI_DAC_Bytes + 1)
   03C5 80 1C              1795 	sjmp	00114$
   03C7                    1796 00108$:
                    02F9   1797 	C$potentiostat_HWtestingMain.c$754$2$2 ==.
                           1798 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:754: else if (Writing_to_RAM > 0)	// RAM
   03C7 C3                 1799 	clr	c
   03C8 E4                 1800 	clr	a
   03C9 95 0C              1801 	subb	a,_Writing_to_RAM
   03CB 74 80              1802 	mov	a,#(0x00 ^ 0x80)
   03CD 85 0D F0           1803 	mov	b,(_Writing_to_RAM + 1)
   03D0 63 F0 80           1804 	xrl	b,#0x80
   03D3 95 F0              1805 	subb	a,b
   03D5 50 0A              1806 	jnc	00105$
                    0309   1807 	C$potentiostat_HWtestingMain.c$756$3$7 ==.
                           1808 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:756: SPI_RAM_Bytes++;			// Do not zero in this ISR
   03D7 05 12              1809 	inc	_SPI_RAM_Bytes
   03D9 E4                 1810 	clr	a
   03DA B5 12 06           1811 	cjne	a,_SPI_RAM_Bytes,00114$
   03DD 05 13              1812 	inc	(_SPI_RAM_Bytes + 1)
   03DF 80 02              1813 	sjmp	00114$
   03E1                    1814 00105$:
                    0313   1815 	C$potentiostat_HWtestingMain.c$760$3$8 ==.
                           1816 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:760: ERRORPIN = 1;
   03E1 D2 A2              1817 	setb	_ERRORPIN
   03E3                    1818 00114$:
                    0315   1819 	C$potentiostat_HWtestingMain.c$763$1$1 ==.
                           1820 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:763: if ((SPI0CN & 0x40) == 0x40)	// write collision
   03E3 74 40              1821 	mov	a,#0x40
   03E5 55 F8              1822 	anl	a,_SPI0CN
   03E7 FA                 1823 	mov	r2,a
   03E8 BA 40 02           1824 	cjne	r2,#0x40,00116$
                    031D   1825 	C$potentiostat_HWtestingMain.c$765$2$9 ==.
                           1826 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:765: WCOL = 0;		// clear interrupt flag
   03EB C2 FE              1827 	clr	_WCOL
   03ED                    1828 00116$:
                    031F   1829 	C$potentiostat_HWtestingMain.c$767$1$1 ==.
                           1830 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:767: if ((SPI0CN & 0x20) == 0x20)	// mode fault
   03ED 74 20              1831 	mov	a,#0x20
   03EF 55 F8              1832 	anl	a,_SPI0CN
   03F1 FA                 1833 	mov	r2,a
   03F2 BA 20 02           1834 	cjne	r2,#0x20,00118$
                    0327   1835 	C$potentiostat_HWtestingMain.c$769$2$10 ==.
                           1836 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:769: MODF = 0;		// clear interrupt flag
   03F5 C2 FD              1837 	clr	_MODF
   03F7                    1838 00118$:
                    0329   1839 	C$potentiostat_HWtestingMain.c$771$1$1 ==.
                           1840 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:771: if ((SPI0CN & 0x10) == 0x10)	// RX overrun
   03F7 74 10              1841 	mov	a,#0x10
   03F9 55 F8              1842 	anl	a,_SPI0CN
   03FB FA                 1843 	mov	r2,a
   03FC BA 10 02           1844 	cjne	r2,#0x10,00121$
                    0331   1845 	C$potentiostat_HWtestingMain.c$773$2$11 ==.
                           1846 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:773: RXOVRN = 0;		// clear interrupt flag
   03FF C2 FC              1847 	clr	_RXOVRN
   0401                    1848 00121$:
   0401 D0 D0              1849 	pop	psw
   0403 D0 03              1850 	pop	ar3
   0405 D0 02              1851 	pop	ar2
   0407 D0 F0              1852 	pop	b
   0409 D0 E0              1853 	pop	acc
                    033D   1854 	C$potentiostat_HWtestingMain.c$775$2$1 ==.
                    033D   1855 	XG$SPI_ISR$0$0 ==.
   040B 32                 1856 	reti
                           1857 ;	eliminated unneeded push/pop dpl
                           1858 ;	eliminated unneeded push/pop dph
                           1859 ;------------------------------------------------------------
                           1860 ;Allocation info for local variables in function 'Timer1_ISR'
                           1861 ;------------------------------------------------------------
                           1862 ;save_Writing_to_DAC       Allocated to registers r2 r3 
                           1863 ;save_Writing_to_RAM       Allocated to registers r4 r5 
                           1864 ;save_NDACCS               Allocated to registers r6 r7 
                           1865 ;save_NRAMCS               Allocated to registers r0 r1 
                           1866 ;------------------------------------------------------------
                    033E   1867 	G$Timer1_ISR$0$0 ==.
                    033E   1868 	C$potentiostat_HWtestingMain.c$776$2$1 ==.
                           1869 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:776: INTERRUPT(Timer1_ISR, INTERRUPT_TIMER1)
                           1870 ;	-----------------------------------------
                           1871 ;	 function Timer1_ISR
                           1872 ;	-----------------------------------------
   040C                    1873 _Timer1_ISR:
   040C C0 E0              1874 	push	acc
   040E C0 02              1875 	push	ar2
   0410 C0 03              1876 	push	ar3
   0412 C0 04              1877 	push	ar4
   0414 C0 05              1878 	push	ar5
   0416 C0 06              1879 	push	ar6
   0418 C0 07              1880 	push	ar7
   041A C0 00              1881 	push	ar0
   041C C0 01              1882 	push	ar1
   041E C0 D0              1883 	push	psw
   0420 75 D0 00           1884 	mov	psw,#0x00
                    0355   1885 	C$potentiostat_HWtestingMain.c$787$1$1 ==.
                           1886 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:787: TF1 = 0;						// Clear Timer2 interrupt flag
   0423 C2 8F              1887 	clr	_TF1
                    0357   1888 	C$potentiostat_HWtestingMain.c$789$1$1 ==.
                           1889 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:789: if (ADC_settled == 0)			// if not settled, still waiting 12 ms
   0425 E5 16              1890 	mov	a,_ADC_settled
   0427 45 17              1891 	orl	a,(_ADC_settled + 1)
   0429 70 21              1892 	jnz	00113$
                    035D   1893 	C$potentiostat_HWtestingMain.c$791$2$2 ==.
                           1894 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:791: ADC_timer++;
   042B 05 14              1895 	inc	_ADC_timer
   042D E4                 1896 	clr	a
   042E B5 14 02           1897 	cjne	a,_ADC_timer,00125$
   0431 05 15              1898 	inc	(_ADC_timer + 1)
   0433                    1899 00125$:
                    0365   1900 	C$potentiostat_HWtestingMain.c$792$2$2 ==.
                           1901 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:792: if (ADC_timer >= 12)
   0433 C3                 1902 	clr	c
   0434 E5 14              1903 	mov	a,_ADC_timer
   0436 94 0C              1904 	subb	a,#0x0C
   0438 E5 15              1905 	mov	a,(_ADC_timer + 1)
   043A 64 80              1906 	xrl	a,#0x80
   043C 94 80              1907 	subb	a,#0x80
   043E 50 03              1908 	jnc	00126$
   0440 02 04 DC           1909 	ljmp	00115$
   0443                    1910 00126$:
                    0375   1911 	C$potentiostat_HWtestingMain.c$794$3$3 ==.
                           1912 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:794: ADC_settled = 1;
   0443 75 16 01           1913 	mov	_ADC_settled,#0x01
   0446 75 17 00           1914 	mov	(_ADC_settled + 1),#0x00
   0449 02 04 DC           1915 	ljmp	00115$
   044C                    1916 00113$:
                    037E   1917 	C$potentiostat_HWtestingMain.c$799$2$4 ==.
                           1918 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:799: if (ADC_timer_MSB < 1)		// Timer needs to execute another time,
   044C C3                 1919 	clr	c
   044D E5 18              1920 	mov	a,_ADC_timer_MSB
   044F 94 01              1921 	subb	a,#0x01
   0451 E5 19              1922 	mov	a,(_ADC_timer_MSB + 1)
   0453 64 80              1923 	xrl	a,#0x80
   0455 94 80              1924 	subb	a,#0x80
   0457 50 0A              1925 	jnc	00110$
                    038B   1926 	C$potentiostat_HWtestingMain.c$801$3$5 ==.
                           1927 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:801: ADC_timer_MSB++;
   0459 05 18              1928 	inc	_ADC_timer_MSB
   045B E4                 1929 	clr	a
   045C B5 18 02           1930 	cjne	a,_ADC_timer_MSB,00128$
   045F 05 19              1931 	inc	(_ADC_timer_MSB + 1)
   0461                    1932 00128$:
   0461 80 79              1933 	sjmp	00115$
   0463                    1934 00110$:
                    0395   1935 	C$potentiostat_HWtestingMain.c$811$3$6 ==.
                           1936 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:811: ESPI0 = 0;
   0463 C2 AE              1937 	clr	_ESPI0
                    0397   1938 	C$potentiostat_HWtestingMain.c$814$3$6 ==.
                           1939 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:814: save_Writing_to_DAC = Writing_to_DAC;
   0465 AA 08              1940 	mov	r2,_Writing_to_DAC
   0467 AB 09              1941 	mov	r3,(_Writing_to_DAC + 1)
                    039B   1942 	C$potentiostat_HWtestingMain.c$815$3$6 ==.
                           1943 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:815: save_Writing_to_RAM = Writing_to_RAM;
   0469 AC 0C              1944 	mov	r4,_Writing_to_RAM
   046B AD 0D              1945 	mov	r5,(_Writing_to_RAM + 1)
                    039F   1946 	C$potentiostat_HWtestingMain.c$816$3$6 ==.
                           1947 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:816: save_NDACCS = NDACCS;
   046D A2 94              1948 	mov	c,_NDACCS
   046F E4                 1949 	clr	a
   0470 33                 1950 	rlc	a
   0471 FE                 1951 	mov	r6,a
   0472 7F 00              1952 	mov	r7,#0x00
                    03A6   1953 	C$potentiostat_HWtestingMain.c$817$3$6 ==.
                           1954 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:817: save_NRAMCS = NRAMCS;
   0474 A2 A6              1955 	mov	c,_NRAMCS
   0476 E4                 1956 	clr	a
   0477 33                 1957 	rlc	a
   0478 F8                 1958 	mov	r0,a
                    03AB   1959 	C$potentiostat_HWtestingMain.c$820$3$6 ==.
                           1960 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:820: Writing_to_DAC = 0;
                    03AB   1961 	C$potentiostat_HWtestingMain.c$821$3$6 ==.
                           1962 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:821: Writing_to_RAM = 0;
   0479 E4                 1963 	clr	a
   047A F9                 1964 	mov	r1,a
   047B F5 08              1965 	mov	_Writing_to_DAC,a
   047D F5 09              1966 	mov	(_Writing_to_DAC + 1),a
   047F F5 0C              1967 	mov	_Writing_to_RAM,a
   0481 F5 0D              1968 	mov	(_Writing_to_RAM + 1),a
                    03B5   1969 	C$potentiostat_HWtestingMain.c$822$3$6 ==.
                           1970 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:822: NDACCS = 1;
   0483 D2 94              1971 	setb	_NDACCS
                    03B7   1972 	C$potentiostat_HWtestingMain.c$823$3$6 ==.
                           1973 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:823: NRAMCS = 1;
   0485 D2 A6              1974 	setb	_NRAMCS
                    03B9   1975 	C$potentiostat_HWtestingMain.c$826$3$6 ==.
                           1976 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:826: NADCCS = 0;						// Select ADC for SPI comm
   0487 C2 A1              1977 	clr	_NADCCS
                    03BB   1978 	C$potentiostat_HWtestingMain.c$827$3$6 ==.
                           1979 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:827: Writing_to_ADC = 1;
   0489 75 0A 01           1980 	mov	_Writing_to_ADC,#0x01
   048C 75 0B 00           1981 	mov	(_Writing_to_ADC + 1),#0x00
                    03C1   1982 	C$potentiostat_HWtestingMain.c$829$3$6 ==.
                           1983 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:829: SPI0CFG = 0x40;					// 0x60 = 0100 0000
   048F 75 A1 40           1984 	mov	_SPI0CFG,#0x40
                    03C4   1985 	C$potentiostat_HWtestingMain.c$830$3$6 ==.
                           1986 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:830: SPI0CKR = 0x05;					// 0x00 = 0000 0101
   0492 75 A2 05           1987 	mov	_SPI0CKR,#0x05
                    03C7   1988 	C$potentiostat_HWtestingMain.c$832$3$6 ==.
                           1989 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:832: SPI0DAT = 0x0;					// Write all zeros to get data
   0495 75 A3 00           1990 	mov	_SPI0DAT,#0x00
                    03CA   1991 	C$potentiostat_HWtestingMain.c$833$3$6 ==.
                           1992 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:833: while(!SPIF) {}					// Poll for SPI to finish sending byte
   0498                    1993 00103$:
   0498 30 FF FD           1994 	jnb	_SPIF,00103$
                    03CD   1995 	C$potentiostat_HWtestingMain.c$834$3$6 ==.
                           1996 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:834: latest_ADC_LowByte = SPI0DAT;	// Read SPI data register
   049B 85 A3 1C           1997 	mov	_latest_ADC_LowByte,_SPI0DAT
   049E 75 1D 00           1998 	mov	(_latest_ADC_LowByte + 1),#0x00
                    03D3   1999 	C$potentiostat_HWtestingMain.c$836$3$6 ==.
                           2000 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:836: SPIF = 0;
   04A1 C2 FF              2001 	clr	_SPIF
                    03D5   2002 	C$potentiostat_HWtestingMain.c$837$3$6 ==.
                           2003 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:837: SPI0DAT = 0x00;					// 0x00 = 0000 0000
   04A3 75 A3 00           2004 	mov	_SPI0DAT,#0x00
                    03D8   2005 	C$potentiostat_HWtestingMain.c$838$3$6 ==.
                           2006 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:838: while(!SPIF) {}					// Poll for SPI to finish sending byte
   04A6                    2007 00106$:
   04A6 30 FF FD           2008 	jnb	_SPIF,00106$
                    03DB   2009 	C$potentiostat_HWtestingMain.c$839$3$6 ==.
                           2010 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:839: latest_ADC_HighByte = SPI0DAT;	// Read SPI data register
   04A9 85 A3 1A           2011 	mov	_latest_ADC_HighByte,_SPI0DAT
   04AC 75 1B 00           2012 	mov	(_latest_ADC_HighByte + 1),#0x00
                    03E1   2013 	C$potentiostat_HWtestingMain.c$841$3$6 ==.
                           2014 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:841: SPIF = 0;
   04AF C2 FF              2015 	clr	_SPIF
                    03E3   2016 	C$potentiostat_HWtestingMain.c$842$3$6 ==.
                           2017 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:842: NADCCS = 1;						// Deselect ADC for SPI comm
   04B1 D2 A1              2018 	setb	_NADCCS
                    03E5   2019 	C$potentiostat_HWtestingMain.c$843$3$6 ==.
                           2020 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:843: Writing_to_ADC = 0;
   04B3 E4                 2021 	clr	a
   04B4 F5 0A              2022 	mov	_Writing_to_ADC,a
   04B6 F5 0B              2023 	mov	(_Writing_to_ADC + 1),a
                    03EA   2024 	C$potentiostat_HWtestingMain.c$846$3$6 ==.
                           2025 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:846: Writing_to_DAC = save_Writing_to_DAC;
   04B8 8A 08              2026 	mov	_Writing_to_DAC,r2
   04BA 8B 09              2027 	mov	(_Writing_to_DAC + 1),r3
                    03EE   2028 	C$potentiostat_HWtestingMain.c$847$3$6 ==.
                           2029 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:847: Writing_to_RAM = save_Writing_to_RAM;
   04BC 8C 0C              2030 	mov	_Writing_to_RAM,r4
   04BE 8D 0D              2031 	mov	(_Writing_to_RAM + 1),r5
                    03F2   2032 	C$potentiostat_HWtestingMain.c$848$3$6 ==.
                           2033 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:848: NDACCS = save_NDACCS;
   04C0 EE                 2034 	mov	a,r6
   04C1 4F                 2035 	orl	a,r7
   04C2 24 FF              2036 	add	a,#0xff
   04C4 92 94              2037 	mov	_NDACCS,c
                    03F8   2038 	C$potentiostat_HWtestingMain.c$849$3$6 ==.
                           2039 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:849: NRAMCS = save_NRAMCS;
   04C6 E8                 2040 	mov	a,r0
   04C7 49                 2041 	orl	a,r1
   04C8 24 FF              2042 	add	a,#0xff
   04CA 92 A6              2043 	mov	_NRAMCS,c
                    03FE   2044 	C$potentiostat_HWtestingMain.c$852$3$6 ==.
                           2045 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:852: ESPI0 = 1;
   04CC D2 AE              2046 	setb	_ESPI0
                    0400   2047 	C$potentiostat_HWtestingMain.c$856$3$6 ==.
                           2048 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:856: Write_to_RAM = 1;
   04CE 75 1E 01           2049 	mov	_Write_to_RAM,#0x01
   04D1 75 1F 00           2050 	mov	(_Write_to_RAM + 1),#0x00
                    0406   2051 	C$potentiostat_HWtestingMain.c$857$3$6 ==.
                           2052 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:857: EIE1 &= 0xFD;					// 0xFD = 1111 1101
   04D4 53 E6 FD           2053 	anl	_EIE1,#0xFD
                    0409   2054 	C$potentiostat_HWtestingMain.c$860$3$6 ==.
                           2055 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:860: ADC_timer_MSB = 0;				// Reset SW timer most significant bit
   04D7 E4                 2056 	clr	a
   04D8 F5 18              2057 	mov	_ADC_timer_MSB,a
   04DA F5 19              2058 	mov	(_ADC_timer_MSB + 1),a
   04DC                    2059 00115$:
   04DC D0 D0              2060 	pop	psw
   04DE D0 01              2061 	pop	ar1
   04E0 D0 00              2062 	pop	ar0
   04E2 D0 07              2063 	pop	ar7
   04E4 D0 06              2064 	pop	ar6
   04E6 D0 05              2065 	pop	ar5
   04E8 D0 04              2066 	pop	ar4
   04EA D0 03              2067 	pop	ar3
   04EC D0 02              2068 	pop	ar2
   04EE D0 E0              2069 	pop	acc
                    0422   2070 	C$potentiostat_HWtestingMain.c$872$1$1 ==.
                    0422   2071 	XG$Timer1_ISR$0$0 ==.
   04F0 32                 2072 	reti
                           2073 ;	eliminated unneeded push/pop dpl
                           2074 ;	eliminated unneeded push/pop dph
                           2075 ;	eliminated unneeded push/pop b
                           2076 ;------------------------------------------------------------
                           2077 ;Allocation info for local variables in function 'Timer2_ISR'
                           2078 ;------------------------------------------------------------
                           2079 ;------------------------------------------------------------
                    0423   2080 	G$Timer2_ISR$0$0 ==.
                    0423   2081 	C$potentiostat_HWtestingMain.c$873$1$1 ==.
                           2082 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:873: INTERRUPT(Timer2_ISR, INTERRUPT_TIMER2)
                           2083 ;	-----------------------------------------
                           2084 ;	 function Timer2_ISR
                           2085 ;	-----------------------------------------
   04F1                    2086 _Timer2_ISR:
                    0423   2087 	C$potentiostat_HWtestingMain.c$875$1$1 ==.
                           2088 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:875: TF2H = 0;                           // Clear Timer2 interrupt flag
   04F1 C2 CF              2089 	clr	_TF2H
                    0425   2090 	C$potentiostat_HWtestingMain.c$877$1$1 ==.
                           2091 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:877: Motor1Step = !Motor1Step;			// Toggle pin so motor 1 steps ever other
   04F3 B2 87              2092 	cpl	_Motor1Step
                    0427   2093 	C$potentiostat_HWtestingMain.c$879$1$1 ==.
                           2094 ;	G:\work\contracts\potentiostat\uController\firmware\potentiostat_HWtesting\potentiostat_HWtestingMain.c:879: Motor2Step = !Motor2Step;			// Toggle pin so motor 1 steps ever other
   04F5 B2 84              2095 	cpl	_Motor2Step
                    0429   2096 	C$potentiostat_HWtestingMain.c$887$1$1 ==.
                    0429   2097 	XG$Timer2_ISR$0$0 ==.
   04F7 32                 2098 	reti
                           2099 ;	eliminated unneeded push/pop psw
                           2100 ;	eliminated unneeded push/pop dpl
                           2101 ;	eliminated unneeded push/pop dph
                           2102 ;	eliminated unneeded push/pop b
                           2103 ;	eliminated unneeded push/pop acc
                           2104 	.area CSEG    (CODE)
                           2105 	.area CONST   (CODE)
                           2106 	.area XINIT   (CODE)
                           2107 	.area CABS    (ABS,CODE)
